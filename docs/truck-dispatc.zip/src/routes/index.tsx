import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  CheckCircle2,
  Clock,
  MapPin,
  Percent,
  ShieldCheck,
} from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { CtaBand, Eyebrow, SectionHeading, StatBand } from "@/components/site/blocks";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { img } from "@/data/images";
import { site, testimonials } from "@/data/site";
import { services } from "@/data/services";
import { posts } from "@/data/blog";

export const Route = createFileRoute("/")({
  head: () =>
    buildHead({
      title: "Truck Dispatch Services for US Carriers | Meridian Dispatch Group",
      description:
        "Professional 24/7 truck dispatching for owner-operators and fleets. Load sourcing, rate negotiation, compliance, and billing — month-to-month, no setup fees.",
    }),
  component: Index,
});

const trustItems = [
  { icon: ShieldCheck, label: "Month-to-month terms" },
  { icon: Percent, label: "No setup fees" },
  { icon: Clock, label: "24/7 dispatch desk" },
  { icon: MapPin, label: "Carriers in 48 states" },
];

const steps = [
  {
    n: "01",
    title: "Tell us about your trucks",
    body: "Equipment, lanes, home-time needs, and your rate floor. One 20-minute call and your dispatcher knows your operation.",
  },
  {
    n: "02",
    title: "We source and negotiate",
    body: "Your dispatcher works the boards and broker relationships daily, negotiating every rate before you commit.",
  },
  {
    n: "03",
    title: "You drive, we handle the rest",
    body: "One clean dispatch sheet per load. Check calls, broker packets, detention claims — all off your plate.",
  },
  {
    n: "04",
    title: "Get paid, see the numbers",
    body: "Invoices go out same-day from PODs. Weekly summaries show exactly what you grossed and where.",
  },
];

function Index() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero */}
        <section className="relative overflow-hidden bg-paper">
          <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:py-20">
            <div>
              <Eyebrow>Truck dispatching · Est. {site.founded}</Eyebrow>
              <h1 className="mt-4 text-4xl font-extrabold leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
                Your trucks, professionally dispatched.{" "}
                <span className="relative whitespace-nowrap text-primary">
                  Around the clock.
                  <span className="absolute -bottom-1 left-0 h-1.5 w-full bg-signal/70" aria-hidden />
                </span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
                Meridian runs the freight office for owner-operators and small
                fleets — sourcing loads, negotiating rates, and handling the
                paperwork that eats your evenings. You drive. We dispatch.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button asChild size="lg" className="rounded-full px-7 font-bold">
                  <Link to="/contact">
                    Get a quote <ArrowRight className="size-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="rounded-full px-7 font-bold">
                  <Link to="/services">Explore services</Link>
                </Button>
              </div>
              <div className="mt-10 flex flex-wrap gap-x-6 gap-y-3">
                {trustItems.map((t) => (
                  <span key={t.label} className="inline-flex items-center gap-2 text-sm font-semibold text-ink-soft">
                    <t.icon className="size-4 text-primary" /> {t.label}
                  </span>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="absolute -right-3 -top-3 hidden h-full w-full rounded-2xl bg-signal lg:block" aria-hidden />
              <img
                src={img.heroFleet}
                alt="Fleet of semi-trucks on an American interstate at sunrise"
                width={1920}
                height={1088}
                className="relative aspect-[16/10] w-full rounded-2xl object-cover shadow-xl"
              />
              <div className="relative -mt-10 ml-4 w-fit rounded-xl border bg-card p-4 shadow-lg lg:absolute lg:bottom-6 lg:left-6 lg:mt-0">
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">This week at Meridian</p>
                <p className="mt-1 font-display text-2xl font-extrabold text-foreground">$912K <span className="text-sm font-semibold text-muted-foreground">freight booked</span></p>
                <p className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-primary">
                  <CheckCircle2 className="size-3.5 text-signal" /> 214 loads dispatched · 48 states
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Services — editorial numbered list */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading
              eyebrow="What we do"
              title="Dispatch desks built around your equipment"
              description="Specialized teams for the freight you actually run — not one generalist dispatcher for everything."
            />
            <Button asChild variant="outline" className="rounded-full font-semibold">
              <Link to="/services">
                All services <ArrowUpRight className="size-4" />
              </Link>
            </Button>
          </div>
          <div className="mt-10 grid gap-x-12 md:grid-cols-2">
            {services.map((s, i) => (
              <Link
                key={s.slug}
                to="/services/$slug"
                params={{ slug: s.slug }}
                className="group flex items-start gap-5 border-t py-6 transition-colors first:border-t-0 hover:bg-secondary/40 md:[&:nth-last-child(-n+2)]:border-b md:[&:nth-child(-n+4)]:border-t lg:[&:nth-last-child(-n+2)]:border-b"
              >
                <span className="mt-1 flex size-11 shrink-0 items-center justify-center rounded-lg bg-primary text-signal transition-colors group-hover:bg-signal group-hover:text-accent-foreground">
                  <s.icon className="size-5" />
                </span>
                <span className="min-w-0">
                  <span className="flex items-baseline gap-3">
                    <span className="font-display text-xs font-bold text-muted-foreground/60">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="font-display text-lg font-bold tracking-tight text-foreground group-hover:underline">
                      {s.title}
                    </span>
                  </span>
                  <span className="mt-1.5 block text-sm leading-relaxed text-muted-foreground">{s.excerpt}</span>
                  <span className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-primary opacity-0 transition-opacity group-hover:opacity-100">
                    Learn more <ArrowRight className="size-3.5" />
                  </span>
                </span>
              </Link>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section className="border-y bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
            <SectionHeading
              align="center"
              eyebrow="How it works"
              title="From first call to first dispatched load in days"
            />
            <div className="relative mt-12 grid gap-8 md:grid-cols-4">
              <div className="absolute left-0 right-0 top-6 hidden lane-divider md:block" aria-hidden />
              {steps.map((step) => (
                <div key={step.n} className="relative">
                  <span className="relative z-10 flex size-12 items-center justify-center rounded-full border-2 border-signal bg-background font-display text-sm font-extrabold text-foreground">
                    {step.n}
                  </span>
                  <h3 className="mt-4 text-base font-bold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Meridian */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="relative order-2 lg:order-1">
              <div className="absolute -left-3 -top-3 hidden h-full w-full rounded-2xl bg-primary lg:block" aria-hidden />
              <img
                src={img.aboutOps}
                alt="Meridian dispatchers working load boards in the operations office"
                loading="lazy"
                width={1600}
                height={1104}
                className="relative aspect-[16/11] w-full rounded-2xl object-cover shadow-lg"
              />
            </div>
            <div className="order-1 lg:order-2">
              <SectionHeading
                eyebrow="Why Meridian"
                title="A dispatch team that answers at 2 AM"
                description="Night loads don't negotiate themselves. Our desks run around the clock, in shifts, with handoff notes — so a breakdown in Tulsa at midnight gets a person, not a voicemail."
              />
              <ul className="mt-8 space-y-4">
                {[
                  "Dedicated dispatcher who knows your trucks by name",
                  "Rates negotiated before you accept — never after",
                  "Detention, layover, and TONU claims pursued for you",
                  "Same-day invoicing and broker credit checks",
                  "Month-to-month terms; no setup fees, no lock-in",
                ].map((point) => (
                  <li key={point} className="flex items-start gap-3">
                    <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-primary" />
                    <span className="text-[0.95rem] font-medium text-foreground">{point}</span>
                  </li>
                ))}
              </ul>
              <Button asChild className="mt-8 rounded-full px-6 font-bold">
                <Link to="/about">
                  Meet the team <ArrowRight className="size-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        <StatBand items={site.stats} />

        {/* Testimonials */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
          <SectionHeading
            align="center"
            eyebrow="From the road"
            title="Carriers who stopped chasing brokers"
          />
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {testimonials.map((t) => (
              <figure
                key={t.name}
                className="flex flex-col rounded-xl border bg-card p-6 transition-shadow hover:shadow-md"
              >
                <span className="font-display text-4xl font-extrabold leading-none text-signal" aria-hidden>
                  "
                </span>
                <blockquote className="mt-2 flex-1 text-sm leading-relaxed text-foreground/90">{t.quote}</blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t pt-4">
                  <Avatar className="size-9">
                    <AvatarFallback className="bg-secondary text-xs font-bold text-primary">{t.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-bold text-foreground">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        {/* Blog preview */}
        <section className="border-t bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="flex flex-wrap items-end justify-between gap-6">
              <SectionHeading
                eyebrow="Freight insights"
                title="Written by working dispatchers"
                description="Rates, compliance, and growth — practical reading for owner-operators and fleet managers."
              />
              <Button asChild variant="outline" className="rounded-full font-semibold">
                <Link to="/blog">
                  Visit the blog <ArrowUpRight className="size-4" />
                </Link>
              </Button>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {posts.slice(0, 3).map((post) => (
                <Link
                  key={post.slug}
                  to="/blog/$slug"
                  params={{ slug: post.slug }}
                  className="group overflow-hidden rounded-xl border bg-card transition-shadow hover:shadow-lg"
                >
                  <div className="aspect-[16/9] overflow-hidden">
                    <img
                      src={post.cover}
                      alt={post.coverAlt}
                      loading="lazy"
                      width={1600}
                      height={1008}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-5">
                    <p className="text-xs font-bold uppercase tracking-wider text-primary">{post.category}</p>
                    <h3 className="mt-2 font-display text-lg font-bold leading-snug tracking-tight group-hover:underline">
                      {post.title}
                    </h3>
                    <p className="mt-2 text-sm text-muted-foreground">{post.date} · {post.readTime}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <CtaBand />
      </main>
      <SiteFooter />
    </div>
  );
}
