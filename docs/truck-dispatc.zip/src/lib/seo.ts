import { site } from "@/data/site";

type HeadInput = {
  title: string;
  description: string;
};

/** Builds consistent per-route head() metadata for public pages. */
export function buildHead({ title, description }: HeadInput) {
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: site.name },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
    ],
  };
}
