import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronRight, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { img } from "@/data/images";
import { site } from "@/data/site";

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.22em] text-ink-soft",
        className,
      )}
    >
      <span className="h-px w-6 bg-signal" aria-hidden />
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div className={cn("max-w-2xl", align === "center" && "mx-auto text-center", className)}>
      <Eyebrow className={align === "center" ? "justify-center" : ""}>{eyebrow}</Eyebrow>
      <h2 className="mt-3 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
        {title}
      </h2>
      {description && <p className="mt-4 text-base leading-relaxed text-muted-foreground">{description}</p>}
    </div>
  );
}

export function Breadcrumbs({ items }: { items: { label: string; to?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1.5 text-sm">
      {items.map((item, i) => (
        <span key={item.label + i} className="inline-flex items-center gap-1.5">
          {i > 0 && <ChevronRight className="size-3.5 text-muted-foreground/60" aria-hidden />}
          {item.to ? (
            <Link to={item.to} className="font-medium text-muted-foreground transition-colors hover:text-foreground">
              {item.label}
            </Link>
          ) : (
            <span className="font-semibold text-foreground">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

export function PageHero({
  eyebrow,
  title,
  description,
  breadcrumbs,
  children,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  breadcrumbs: { label: string; to?: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="border-b bg-paper">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-20">
        <Breadcrumbs items={breadcrumbs} />
        <div className="mt-6 max-w-3xl">
          <Eyebrow>{eyebrow}</Eyebrow>
          <h1 className="mt-3 text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl">
            {title}
          </h1>
          {description && (
            <p className="mt-5 max-w-2xl text-lg leading-relaxed text-muted-foreground">{description}</p>
          )}
          {children}
        </div>
      </div>
    </section>
  );
}

export function StatBand({
  items,
  className,
}: {
  items: { value: string; label: string }[];
  className?: string;
}) {
  return (
    <section className={cn("bg-signal", className)}>
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-y-8 px-4 py-10 sm:px-6 md:grid-cols-4 md:py-12">
        {items.map((s) => (
          <div key={s.label} className="text-center">
            <p className="font-display text-4xl font-extrabold tracking-tight text-accent-foreground md:text-5xl">
              {s.value}
            </p>
            <p className="mt-1.5 text-sm font-semibold text-accent-foreground/70">{s.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function CtaBand({
  title = "Ready to put a dispatch desk behind your truck?",
  body = "Tell us about your equipment and lanes. We'll respond with a clear plan and an honest rate — usually within one business hour.",
}: {
  title?: string;
  body?: string;
}) {
  return (
    <section className="relative isolate overflow-hidden">
      <img
        src={img.ctaYard}
        alt="Freight distribution yard at dusk"
        loading="lazy"
        width={1920}
        height={912}
        className="absolute inset-0 -z-10 h-full w-full object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-harbor-deep/85" />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">{title}</h2>
          <p className="mt-4 text-base leading-relaxed text-white/70">{body}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg" className="rounded-full bg-signal font-bold text-accent-foreground hover:bg-signal/90">
              <Link to="/contact">Get a quote</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="rounded-full border-white/30 bg-transparent font-bold text-white hover:bg-white/10 hover:text-white">
              <a href={`tel:${site.dispatchLine.replace(/\D/g, "")}`}>
                <Phone className="size-4" /> Call {site.dispatchLine}
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
