export const site = {
  name: "Meridian Dispatch Group",
  shortName: "Meridian",
  legalName: "Meridian Dispatch Group LLC",
  tagline: "Truck dispatching built for carriers that mean business.",
  founded: 2017,
  phone: "(469) 555-0142",
  dispatchLine: "(469) 555-0199",
  email: "dispatch@meridiandispatch.com",
  careersEmail: "careers@meridiandispatch.com",
  address: "4100 Alpha Rd, Suite 520, Dallas, TX 75244",
  hours: [
    { label: "Dispatch desk", value: "24/7, every day" },
    { label: "Office & onboarding", value: "Mon–Fri, 8:00 AM – 6:00 PM CT" },
    { label: "Billing support", value: "Mon–Fri, 9:00 AM – 5:00 PM CT" },
  ],
  serviceArea: "48 contiguous states",
  socials: [
    { label: "LinkedIn", href: "https://www.linkedin.com", icon: "linkedin" },
    { label: "Facebook", href: "https://www.facebook.com", icon: "facebook" },
    { label: "Instagram", href: "https://www.instagram.com", icon: "instagram" },
    { label: "X", href: "https://x.com", icon: "x" },
  ],
  stats: [
    { value: "140+", label: "Carriers dispatched" },
    { value: "$38M", label: "Freight booked annually" },
    { value: "48", label: "States covered" },
    { value: "24/7", label: "Dispatch desk" },
  ],
};

export const publicNav = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Careers", to: "/careers" },
  { label: "Blog", to: "/blog" },
  { label: "FAQs", to: "/faqs" },
  { label: "Contact", to: "/contact" },
];

export const footerNav = [
  {
    heading: "Services",
    links: [
      { label: "Dry Van Dispatching", to: "/services/dry-van-dispatching" },
      { label: "Refrigerated Dispatching", to: "/services/refrigerated-dispatching" },
      { label: "Flatbed & Step Deck", to: "/services/flatbed-step-deck-dispatching" },
      { label: "Power Only Dispatching", to: "/services/power-only-dispatching" },
      { label: "Carrier Setup & Compliance", to: "/services/carrier-setup-compliance" },
      { label: "Billing & Paperwork", to: "/services/billing-paperwork-support" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "About us", to: "/about" },
      { label: "Services", to: "/services" },
      { label: "Careers", to: "/careers" },
      { label: "Blog", to: "/blog" },
      { label: "FAQs", to: "/faqs" },
      { label: "Contact", to: "/contact" },
    ],
  },
  {
    heading: "Legal",
    links: [
      { label: "Privacy policy", to: "/privacy" },
      { label: "Terms & conditions", to: "/terms" },
      { label: "Admin portal", to: "/admin" },
    ],
  },
];

export const testimonials = [
  {
    quote:
      "Meridian took dispatching off my plate completely. I grossed more in my first six months with them than in the previous year running my own numbers — and I finally get home weekly.",
    name: "Ray Delgado",
    role: "Owner-Operator · 1 truck, dry van",
    initials: "RD",
  },
  {
    quote:
      "Their night desk keeps our trucks loaded while we sleep. Rate confirmations, permits, lumper codes — everything is ready before the driver wakes up.",
    name: "Amira Osei",
    role: "Fleet Manager · 14 trucks, reefer",
    initials: "AO",
  },
  {
    quote:
      "We switched from a big brokerage-led setup and the difference is night and day. Meridian negotiates like the freight is theirs and documents everything.",
    name: "Tom Whitaker",
    role: "President · 9 trucks, flatbed",
    initials: "TW",
  },
];
