import heroFleet from "@/assets/hero-fleet.jpg";
import aboutOps from "@/assets/about-ops.jpg";
import careersDriver from "@/assets/careers-driver.jpg";
import ctaYard from "@/assets/cta-yard.jpg";
import svcDryVan from "@/assets/svc-dryvan.jpg";
import svcReefer from "@/assets/svc-reefer.jpg";

/**
 * Central image registry. All photography lives in src/assets and is imported
 * (bundled) rather than hot-linked, so client deployments can swap the files
 * without touching code.
 */
export const img = {
  heroFleet,
  aboutOps,
  careersDriver,
  ctaYard,
  svcDryVan,
  svcReefer,
};
