import { createFileRoute, notFound } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle2, Clock, MapPin, Phone, Users } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { Breadcrumbs, CtaBand, Eyebrow, SectionHeading } from "@/components/site/blocks";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getJob } from "@/data/careers";
import { site } from "@/data/site";

export const Route = createFileRoute("/careers/$slug")({
  head: ({ loaderData }) => {
    const job = loaderData?.job;
    return buildHead({
      title: job ? `${job.title} | Meridian Dispatch Group Careers` : "Job | Meridian Dispatch Group",
      description: job?.overview ?? "Open roles at Meridian Dispatch Group.",
    });
  },
  loader: ({ params }) => {
    const job = getJob(params.slug);
    if (!job) throw notFound();
    return { job };
  },
  component: JobDetail,
});

function JobDetail() {
  const { job } = Route.useLoaderData();

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="border-b bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:py-16">
            <Breadcrumbs
              items={[
                { label: "Home", to: "/" },
                { label: "Careers", to: "/careers" },
                { label: job.title },
              ]}
            />
            <div className="mt-8 max-w-3xl">
              <div className="flex flex-wrap items-center gap-3">
                <Eyebrow>{job.department}</Eyebrow>
                {job.status === "Closed" ? (
                  <Badge variant="outline">Closed</Badge>
                ) : (
                  <Badge className="bg-signal font-semibold text-accent-foreground">Open</Badge>
                )}
              </div>
              <h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">{job.title}</h1>
              <p className="mt-5 text-lg leading-relaxed text-muted-foreground">{job.overview}</p>
              <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium text-ink-soft">
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="size-4 text-primary" /> {job.location}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="size-4 text-primary" /> {job.type}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Users className="size-4 text-primary" /> {job.applicants} applicants · {job.views} views
                </span>
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                {job.status === "Open" ? (
                  <Button asChild size="lg" className="rounded-full px-7 font-bold">
                    <a href={`/careers/${job.slug}/apply`}>Apply for this role</a>
                  </Button>
                ) : (
                  <Button size="lg" disabled className="rounded-full px-7 font-bold">
                    Applications closed
                  </Button>
                )}
                <Button asChild size="lg" variant="outline" className="rounded-full px-7 font-bold">
                  <a href={`mailto:${site.careersEmail}`}>
                    <Phone className="size-4" /> {site.careersEmail}
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <div className="grid gap-12 lg:grid-cols-[1.2fr_1fr]">
            <div className="space-y-12">
              <div>
                <SectionHeading eyebrow="The role" title="What you'll do" />
                <ul className="mt-6 space-y-3">
                  {job.responsibilities.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-[0.95rem] text-foreground/90">
                      <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-signal" aria-hidden />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <SectionHeading eyebrow="Experience" title="What we're looking for" />
                <ul className="mt-6 space-y-3">
                  {job.qualifications.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-[0.95rem] text-foreground/90">
                      <CheckCircle2 className="mt-0.5 size-4.5 shrink-0 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <aside className="space-y-6">
              <div className="rounded-xl border bg-card p-6">
                <h3 className="font-display text-lg font-bold">Position details</h3>
                <dl className="mt-4 space-y-3 text-sm">
                  {[
                    ["Department", job.department],
                    ["Type", job.type],
                    ["Location", job.location],
                    ["Compensation", job.salary],
                    ["Posted", job.posted],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-4 border-b border-border/60 pb-3 last:border-0 last:pb-0">
                      <dt className="text-muted-foreground">{k}</dt>
                      <dd className="text-right font-semibold">{v}</dd>
                    </div>
                  ))}
                </dl>
              </div>
              <div className="rounded-xl border bg-card p-6">
                <h3 className="font-display text-lg font-bold">Benefits</h3>
                <ul className="mt-4 space-y-3">
                  {job.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-2.5 text-sm text-foreground/90">
                      <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" />
                      {b}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl bg-signal p-6">
                <p className="font-display text-base font-bold leading-snug text-accent-foreground">
                  Most candidates complete our process in two weeks — intro call, practical exercise, panel.
                </p>
              </div>
            </aside>
          </div>
          <div className="mt-12">
            <Button asChild variant="ghost" size="sm" className="font-semibold">
              <a href="/careers">
                <ArrowLeft className="size-4" /> All open roles
              </a>
            </Button>
          </div>
        </section>

        {job.status === "Open" && <CtaBand />}
      </main>
      <SiteFooter />
    </div>
  );
}
