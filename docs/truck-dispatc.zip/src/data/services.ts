import {
  Box,
  Snowflake,
  Layers,
  Plug,
  ShieldCheck,
  FileSpreadsheet,
  type LucideIcon,
} from "lucide-react";
import { img } from "./images";

export type Service = {
  slug: string;
  title: string;
  shortTitle: string;
  icon: LucideIcon;
  excerpt: string;
  intro: string;
  image?: string;
  imageAlt?: string;
  included: string[];
  idealFor: string[];
  process: { title: string; body: string }[];
};

export const services: Service[] = [
  {
    slug: "dry-van-dispatching",
    title: "Dry Van Dispatching",
    shortTitle: "Dry Van",
    icon: Box,
    excerpt:
      "Full-service dispatching for dry van carriers — freight sourced, rates negotiated, and paperwork handled while you drive.",
    intro:
      "Dry van freight is the backbone of most American carriers, and it is also the most competitive board in the market. Our dispatchers work the load boards, broker relationships, and contract lanes daily to keep your truck rolling at rates that protect your margin — not just the next available load.",
    image: img.svcDryVan,
    imageAlt: "Dry van semi-truck on an interstate highway",
    included: [
      "Daily load sourcing matched to your lanes, home time, and equipment",
      "Rate negotiation with brokers and shippers before you commit",
      "Complete broker setup packets and rate confirmations",
      "Direction and paperwork for check calls, BOLs, and PODs",
      "Detention, TONU, and layover claims pursued on your behalf",
      "Weekly settlement summaries with gross, mileage, and broker mix",
    ],
    idealFor: [
      "Owner-operators running one to three trucks",
      "Small carriers tired of chasing brokers after hours",
      "Fleets that want consistent lanes instead of spot-market roulette",
    ],
    process: [
      {
        title: "Onboard your operation",
        body: "We collect your authority, insurance, W-9, and preferences once. Your dispatcher learns your equipment, lanes, and home-time schedule.",
      },
      {
        title: "Source and negotiate",
        body: "Your dispatcher hunts loads on every major board and through direct broker relationships, then negotiates rate and terms before anything reaches you.",
      },
      {
        title: "Dispatch and support",
        body: "You get one clean dispatch sheet per load. While you drive, we handle check calls, broker packets, and any trouble on the road.",
      },
      {
        title: "Close the loop",
        body: "Invoices, PODs, and broker follow-ups are handled for you. You receive a weekly summary of what you grossed and where.",
      },
    ],
  },
  {
    slug: "refrigerated-dispatching",
    title: "Refrigerated Dispatching",
    shortTitle: "Reefer",
    icon: Snowflake,
    excerpt:
      "Temperature-controlled freight dispatching with the clock discipline reefer loads demand — claims-aware, appointment-ready.",
    intro:
      "Reefer freight punishes sloppy dispatching. Tight pickup windows, continuous temperature records, and strict appointment times mean your dispatcher has to stay ahead of the load, not react to it. Our reefer desk plans every move with cold-chain discipline.",
    image: img.svcReefer,
    imageAlt: "Refrigerated trailer at a distribution warehouse",
    included: [
      "Load planning around pickup windows and delivery appointments",
      "Pre-cool reminders and temperature documentation guidance",
      "Claims-aware handling of pulp, shrinkage, and delay disputes",
      "Lumper arrangements and codes coordinated in advance",
      "Weekend and overnight coverage for perishable schedules",
      "Broker vetting focused on produce and food-grade pay habits",
    ],
    idealFor: [
      "Reefer owner-operators in produce and food lanes",
      "Small fleets moving temperature-controlled freight regionally",
      "Carriers who have lost money to unanswered detention claims",
    ],
    process: [
      {
        title: "Map your lanes",
        body: "We profile your reefer unit, capacity, and the regions where you run profitably — then build a lane plan around seasonal freight.",
      },
      {
        title: "Book with the clock in mind",
        body: "Every load is checked for realistic windows and appointment times before dispatch. No unrealistic schedules, no surprises.",
      },
      {
        title: "Run the load tight",
        body: "You get appointment cards, lumper codes, and temperature guidance up front. Our desk monitors the load until the POD is in.",
      },
      {
        title: "Protect the settlement",
        body: "Delays and claims are documented from the first call. We compile the evidence so you get paid for the time you actually lost.",
      },
    ],
  },
  {
    slug: "flatbed-step-deck-dispatching",
    title: "Flatbed & Step Deck Dispatching",
    shortTitle: "Flatbed",
    icon: Layers,
    excerpt:
      "Specialized dispatching for flatbed, step deck, and overdimensional freight — securement plans and permits handled.",
    intro:
      "Flatbed pays better because it demands more: tarping, securement math, permits, and routing around restrictions. Our specialized desk works with drivers who take pride in the craft and deserve a dispatcher who understands it.",
    imageAlt: "Flatbed trailer loaded with construction equipment",
    included: [
      "Freight sourcing across construction, steel, machinery, and building products",
      "Overdimensional and overweight permit coordination by state",
      "Routing that accounts for restrictions, curfews, and escort needs",
      "Securement and tarping guidance matched to the commodity",
      "Rate negotiation that prices the extra work, not just the miles",
      "Direct relationships with lumber yards and machine movers",
    ],
    idealFor: [
      "Experienced flatbed drivers who want premium freight only",
      "Step deck and RGN operators moving machinery",
      "Carriers expanding into specialized freight safely",
    ],
    process: [
      {
        title: "Certify your operation",
        body: "We review your securement experience, tarps, chains, and equipment so we only dispatch freight you can legally and safely haul.",
      },
      {
        title: "Quote the full job",
        body: "Permits, escorts, tarps, and tarp-off time are priced into the rate before you accept. No surprise economics halfway to the shipper.",
      },
      {
        title: "Coordinate the move",
        body: "Permits are filed, routes are checked state by state, and delivery constraints are confirmed before wheels roll.",
      },
      {
        title: "Invoice everything",
        body: "Tarp fees, permit passthroughs, and extra stops are itemized so the settlement matches the work.",
      },
    ],
  },
  {
    slug: "power-only-dispatching",
    title: "Power Only Dispatching",
    shortTitle: "Power Only",
    icon: Plug,
    excerpt:
      "Drop-and-hook power only freight that keeps your tractor earning without a trailer payment.",
    intro:
      "Power only removes the trailer from your balance sheet and puts drop-and-hook freight in front of your tractor. We work with trailer pools and power only networks to build consistent week-over-week freight plans.",
    imageAlt: "Semi-tractor picking up a drop trailer at a trailer pool",
    included: [
      "Access to established trailer pools and power only networks",
      "Drop-and-hook heavy lane plans with realistic dwell expectations",
      "Trailer swap coordination and pool compliance paperwork",
      "Rate negotiation on par with full-truckload spot rates",
      "Deadhead-minimizing planning between pool locations",
      "Flexible regional or cross-country lane options",
    ],
    idealFor: [
      "Tractor-only owners avoiding trailer payments",
      "Carriers who want maximum drop-and-hook percentage",
      "Owner-operators prioritizing predictable home time",
    ],
    process: [
      {
        title: "Check network fit",
        body: "We verify your equipment with the trailer pools and power only networks that match your preferred region.",
      },
      {
        title: "Build the week",
        body: "Your dispatcher stacks drop-and-hook loads with short deadheads so the week plans itself around home time.",
      },
      {
        title: "Keep it moving",
        body: "Trailer assignments, pool check-ins, and swap paperwork are managed before you arrive at the yard.",
      },
      {
        title: "Scale when ready",
        body: "Because the trailer isn't your problem, adding a second or third tractor is a paperwork change, not a capital raise.",
      },
    ],
  },
  {
    slug: "carrier-setup-compliance",
    title: "Carrier Setup & Compliance",
    shortTitle: "Setup & Compliance",
    icon: ShieldCheck,
    excerpt:
      "Broker packets, authority paperwork, and FMCSA compliance handled by people who file them every day.",
    intro:
      "Getting set up correctly the first time is the difference between hauling in week two and sitting for a month. Our compliance team prepares broker packets, monitors your safety profile, and keeps your paperwork current so freight never waits on a filing.",
    included: [
      "Complete broker packet assembly and submission tracking",
      "Authority, MC, and DOT registration guidance",
      "Insurance certificate management and renewals",
      "FMCSA safety profile monitoring and correction plans",
      "UCR, IFTA, and IRP filing support",
      "W-9, COI, and carrier profile maintenance across your broker list",
    ],
    idealFor: [
      "New authorities that need to get loads fast",
      "Growing carriers adding brokers and lanes quickly",
      "Any carrier with a compliance question it can't afford to guess on",
    ],
    process: [
      {
        title: "Audit where you stand",
        body: "We review your authority, insurance, and safety profile, then build a short list of what must be fixed before freight can flow.",
      },
      {
        title: "Build your packet",
        body: "W-9, COI, authority letters, and references are assembled into a clean, professional carrier packet.",
      },
      {
        title: "Set you up everywhere",
        body: "We submit setups to brokers and track every confirmation so you know exactly which doors are open.",
      },
      {
        title: "Keep you current",
        body: "Renewals, updates, and monitoring run continuously — compliance stops being a fire drill.",
      },
    ],
  },
  {
    slug: "billing-paperwork-support",
    title: "Billing & Paperwork Support",
    shortTitle: "Billing",
    icon: FileSpreadsheet,
    excerpt:
      "Invoicing, collections, and document management that turns finished loads into settled cash faster.",
    intro:
      "A load isn't revenue until the invoice clears. Our back office turns PODs into invoices the same day, follows up on slow brokers, and keeps your paperwork audit-ready — so you spend evenings with your family instead of your scanner.",
    included: [
      "Same-day invoicing from PODs and rate confirmations",
      "Broker credit checks before you commit to a load",
      "Collection follow-ups on past-due invoices",
      "Lumper, detention, and accessorials billed and tracked",
      "Organized document storage for every load",
      "Clear weekly and monthly revenue reporting",
    ],
    idealFor: [
      "Owner-operators who hate chasing paperwork",
      "Carriers with 30+ day broker payment terms",
      "Operations that want clean books without hiring office staff",
    ],
    process: [
      {
        title: "Send us the POD",
        body: "Snap the POD from the road. Our back office takes it from there — no scanner, no spreadsheet, no stamps.",
      },
      {
        title: "We invoice the same day",
        body: "Invoices go out with complete backup documentation, which is exactly what gets slow brokers to pay faster.",
      },
      {
        title: "We chase, you don't",
        body: "Aging invoices get structured follow-up so your cash flow stays predictable through the month.",
      },
      {
        title: "You see the full picture",
        body: "Weekly statements show gross, outstanding, and paid — by broker, lane, and truck if you want it that granular.",
      },
    ],
  },
];

export function getService(slug: string) {
  return services.find((s) => s.slug === slug);
}
