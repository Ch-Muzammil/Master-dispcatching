import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, Handshake, MessageSquareHeart, Route as RouteIcon, ShieldCheck } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { CtaBand, PageHero, SectionHeading, StatBand } from "@/components/site/blocks";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { img } from "@/data/images";
import { site } from "@/data/site";

export const Route = createFileRoute("/about")({
  head: () =>
    buildHead({
      title: "About Us | Meridian Dispatch Group",
      description:
        "Founded in 2017 in Dallas, Meridian Dispatch Group runs 24/7 dispatch desks for owner-operators and small fleets across 48 states. Meet the team and the values behind the freight.",
    }),
  component: About,
});

const values = [
  {
    icon: ShieldCheck,
    title: "Protect the truck first",
    body: "Every decision starts with the carrier's margin and safety record. If a load isn't good for your operation, it isn't good for us — whatever the commission.",
  },
  {
    icon: MessageSquareHeart,
    title: "Answer like a person",
    body: "No ticket queues for breakdowns. When a driver calls, they reach a dispatcher who knows their truck, lanes, and last three loads.",
  },
  {
    icon: RouteIcon,
    title: "Master the craft",
    body: "Dispatching is a trade. We train it, document it, and review it weekly — negotiation, routing, paperwork, and the judgment that ties them together.",
  },
  {
    icon: Handshake,
    title: "Month-to-month trust",
    body: "We don't lock carriers into contracts. If we earn the desk every month, we keep it — that pressure keeps us honest.",
  },
];

const team = [
  { name: "Dana Whitfield", role: "Head of Carrier Success", initials: "DW", bio: "14 years in freight; built our onboarding playbook from zero." },
  { name: "Marcus Bell", role: "Director of Dispatch Operations", initials: "MB", bio: "Ran a 60-truck brokerage desk before joining Meridian in 2019." },
  { name: "Priya Raman", role: "Compliance Lead", initials: "PR", bio: "Guided 100+ carriers through FMCSA audits and corrections." },
  { name: "Andre Coleman", role: "Night Desk Supervisor", initials: "AC", bio: "Former owner-operator; keeps the overnight freight moving." },
];

const milestones = [
  { year: "2017", text: "Founded in Dallas with two dispatchers and six owner-operators." },
  { year: "2019", text: "Opened the 24/7 night desk after months of carrier requests." },
  { year: "2022", text: "Launched dedicated reefer and flatbed desks; crossed 100 carriers." },
  { year: "2026", text: "140 carriers dispatched, $38M in annual freight booked." },
];

function About() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <PageHero
          eyebrow="About us"
          title="The freight office behind 140 trucks"
          description="Meridian Dispatch Group was built for a specific carrier: the owner-operator or small fleet that can't afford a full back office but deserves the same professionalism the big guys get."
          breadcrumbs={[{ label: "Home", to: "/" }, { label: "About us" }]}
        />

        {/* Story */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <SectionHeading
                eyebrow="Our story"
                title="Started by dispatchers, not salespeople"
              />
              <div className="mt-6 space-y-4 text-base leading-relaxed text-muted-foreground">
                <p>
                  In 2017, our founder was dispatching a handful of owner-operators
                  out of a shared Dallas office — the kind of desk where you learn
                  every driver's voice and every broker's habits. The business grew
                  the honest way: one clean settlement at a time, one carrier
                  referral at a time.
                </p>
                <p>
                  Nine years later the operation is bigger, but the shape hasn't
                  changed. Every carrier gets a named dispatcher. Every load gets
                  negotiated before acceptance. Every night shift ends with written
                  handoff notes. We've stayed deliberately small per desk, because
                  dispatching quality dies at scale.
                </p>
                <p>
                  Today Meridian runs specialized desks for dry van, reefer,
                  flatbed, and power only operations, backed by compliance and
                  billing teams — serving carriers across the lower 48 states.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -right-3 -top-3 hidden h-full w-full rounded-2xl bg-signal lg:block" aria-hidden />
              <img
                src={img.aboutOps}
                alt="Dispatch operations floor at Meridian's Dallas office"
                loading="lazy"
                width={1600}
                height={1104}
                className="relative aspect-[16/11] w-full rounded-2xl object-cover shadow-lg"
              />
            </div>
          </div>
        </section>

        <StatBand items={site.stats} />

        {/* Values */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
          <SectionHeading
            align="center"
            eyebrow="What we stand for"
            title="Four values, applied daily"
          />
          <div className="mt-12 grid gap-6 sm:grid-cols-2">
            {values.map((v) => (
              <div key={v.title} className="flex gap-5 rounded-xl border bg-card p-6">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
                  <v.icon className="size-5" />
                </span>
                <div>
                  <h3 className="font-display text-lg font-bold tracking-tight">{v.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{v.body}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Timeline + team */}
        <section className="border-y bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="grid gap-14 lg:grid-cols-[1fr_1.2fr]">
              <div>
                <SectionHeading eyebrow="Milestones" title="Nine years on the boards" />
                <ol className="mt-8 space-y-6 border-l-2 border-signal/60 pl-6">
                  {milestones.map((m) => (
                    <li key={m.year} className="relative">
                      <span className="absolute -left-[1.9rem] top-1 size-3 rounded-full border-2 border-signal bg-background" aria-hidden />
                      <p className="font-display text-lg font-extrabold text-primary">{m.year}</p>
                      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{m.text}</p>
                    </li>
                  ))}
                </ol>
              </div>
              <div>
                <SectionHeading eyebrow="Leadership" title="The people on the desks" />
                <div className="mt-8 grid gap-5 sm:grid-cols-2">
                  {team.map((person) => (
                    <div key={person.name} className="rounded-xl border bg-card p-5">
                      <Avatar className="size-12">
                        <AvatarFallback className="bg-primary font-display text-sm font-bold text-signal">
                          {person.initials}
                        </AvatarFallback>
                      </Avatar>
                      <h3 className="mt-3 font-display text-base font-bold">{person.name}</h3>
                      <p className="text-xs font-semibold uppercase tracking-wide text-primary">{person.role}</p>
                      <p className="mt-2 text-sm text-muted-foreground">{person.bio}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Culture CTA */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <div className="flex flex-col items-start justify-between gap-6 rounded-2xl border bg-card p-8 sm:flex-row sm:items-center lg:p-10">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Like the sound of the desk?</h2>
              <p className="mt-2 max-w-xl text-muted-foreground">
                We hire dispatchers, load planners, and compliance specialists — several of our leads started in seats just like them.
              </p>
            </div>
            <Button asChild size="lg" className="shrink-0 rounded-full px-7 font-bold">
              <Link to="/careers">
                See open roles <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </section>

        <CtaBand
          title="Put our desks to work on your trucks"
          body="Tell us about your equipment and lanes — we'll respond with a clear plan and an honest rate, usually within one business hour."
        />
      </main>
      <SiteFooter />
    </div>
  );
}
