import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin, Users } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { CtaBand, PageHero, SectionHeading } from "@/components/site/blocks";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { img } from "@/data/images";
import { jobDepartments, jobs } from "@/data/careers";

export const Route = createFileRoute("/careers")({
  head: () =>
    buildHead({
      title: "Careers | Meridian Dispatch Group",
      description:
        "Join a dispatch team that treats freight like a craft. Open roles in dispatch operations, carrier success, and compliance — remote and Dallas-based.",
    }),
  component: Careers,
});

function Careers() {
  const [dept, setDept] = useState(jobDepartments[0]);
  const open = jobs.filter(
    (j) => j.status === "Open" && (dept === jobDepartments[0] || j.department === dept),
  );
  const closed = jobs.filter((j) => j.status === "Closed");

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="border-b bg-paper">
          <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:py-20">
            <div>
              <PageHero
                eyebrow="Careers"
                title="Work the freight, learn the craft"
                description="We're dispatchers, coordinators, and compliance specialists who treat trucking like a trade worth mastering. Small teams, real desks, and mentorship from people who've lived the load boards."
                breadcrumbs={[{ label: "Home", to: "/" }, { label: "Careers" }]}
              />
            </div>
            <img
              src={img.careersDriver}
              alt="Meridian dispatcher on a call with a driver"
              loading="lazy"
              width={1600}
              height={1104}
              className="aspect-[16/10] w-full rounded-2xl object-cover shadow-lg"
            />
          </div>
        </section>

        {/* Openings */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading
              eyebrow="Open positions"
              title={`${open.length} role${open.length === 1 ? "" : "s"} open right now`}
            />
            <div className="flex flex-wrap gap-2">
              {jobDepartments.map((d) => (
                <button
                  key={d}
                  onClick={() => setDept(d)}
                  className={
                    d === dept
                      ? "rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground"
                      : "rounded-full border border-input bg-background px-4 py-1.5 text-sm font-semibold text-muted-foreground transition-colors hover:bg-secondary"
                  }
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-10 space-y-4">
            {open.map((job) => (
              <Link
                key={job.slug}
                to="/careers/$slug"
                params={{ slug: job.slug }}
                className="group grid gap-4 rounded-xl border bg-card p-6 transition-all hover:-translate-y-0.5 hover:border-signal hover:shadow-lg sm:p-8 lg:grid-cols-[1fr_auto] lg:items-center"
              >
                <div>
                  <div className="flex flex-wrap items-center gap-3">
                    <h2 className="font-display text-xl font-bold tracking-tight group-hover:underline sm:text-2xl">
                      {job.title}
                    </h2>
                    <Badge variant="secondary">{job.department}</Badge>
                  </div>
                  <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                    {job.overview}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs font-medium text-ink-soft">
                    <span className="inline-flex items-center gap-1.5">
                      <MapPin className="size-3.5 text-primary" /> {job.location}
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Users className="size-3.5 text-primary" /> {job.applicants} applicants
                    </span>
                    <span>{job.salary}</span>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1.5 self-start text-sm font-bold text-primary lg:self-center">
                  View role
                  <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                </span>
              </Link>
            ))}
            {open.length === 0 && (
              <p className="rounded-xl border bg-card p-8 text-center text-sm text-muted-foreground">
                No open roles in this department right now — check back soon.
              </p>
            )}
          </div>

          {closed.length > 0 && (
            <div className="mt-10 border-t pt-8">
              <h3 className="text-sm font-bold uppercase tracking-[0.18em] text-ink-soft">
                Recently closed
              </h3>
              <ul className="mt-4 space-y-2">
                {closed.map((job) => (
                  <li key={job.slug} className="flex flex-wrap items-center gap-3 text-sm">
                    <span className="font-semibold text-muted-foreground">{job.title}</span>
                    <Badge variant="outline">Closed · {job.posted}</Badge>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>

        <CtaBand
          title="Don't see your role listed?"
          body="We hire hungry people ahead of openings when the fit is right. Send a note about how you'd strengthen the desk and we'll keep it on file."
        />
      </main>
      <SiteFooter />
    </div>
  );
}
