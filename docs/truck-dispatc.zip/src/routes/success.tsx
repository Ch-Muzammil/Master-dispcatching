import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, Home, Mail } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { Button } from "@/components/ui/button";
import { site } from "@/data/site";

type Search = { from?: string };

const variants = {
  contact: {
    title: "Message received",
    body: "Thanks for reaching out. A dispatcher will reply to your inquiry within one business hour during desk hours — usually sooner.",
    next: { label: "Back to home", to: "/" } as const,
  },
  application: {
    title: "Application submitted",
    body: `Thanks for applying — our hiring team reviews every application personally. Expect to hear from us at the email you provided within two business days, or reach us at ${site.careersEmail}.`,
    next: { label: "Browse open roles", to: "/careers" } as const,
  },
};

export const Route = createFileRoute("/success")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    from: typeof search.from === "string" ? search.from : undefined,
  }),
  head: () =>
    buildHead({
      title: "Thank you | Meridian Dispatch Group",
      description: "Your submission was received — here's what happens next.",
    }),
  component: SuccessPage,
});

function SuccessPage() {
  const { from } = Route.useSearch();
  const v = from === "application" ? variants.application : variants.contact;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex flex-1 items-center justify-center bg-paper px-4 py-20">
        <div className="w-full max-w-lg rounded-2xl border bg-card p-10 text-center shadow-sm">
          <span className="mx-auto flex size-14 items-center justify-center rounded-full bg-signal">
            <CheckCircle2 className="size-7 text-accent-foreground" />
          </span>
          <h1 className="mt-6 text-3xl font-extrabold tracking-tight">{v.title}</h1>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">{v.body}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" className="rounded-full px-7 font-bold">
              <Link to={v.next.to}>
                <Home className="size-4" /> {v.next.label}
              </Link>
            </Button>
            {from === "contact" && (
              <Button asChild size="lg" variant="outline" className="rounded-full px-7 font-bold">
                <a href={`mailto:${site.email}`}>
                  <Mail className="size-4" /> Email us directly
                </a>
              </Button>
            )}
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
