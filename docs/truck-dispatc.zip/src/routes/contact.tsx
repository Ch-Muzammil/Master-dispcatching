import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Clock, Mail, MapPin, Phone, Send } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { Eyebrow } from "@/components/site/blocks";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { site } from "@/data/site";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () =>
    buildHead({
      title: "Contact | Meridian Dispatch Group",
      description:
        "Talk to a dispatcher about your trucks. 24/7 dispatch line, Dallas HQ, and a quick inquiry form answered within one business hour.",
    }),
  component: Contact,
});

type Errors = Partial<Record<"name" | "email" | "message", string>>;

function Contact() {
  const navigate = useNavigate();
  const [errors, setErrors] = useState<Errors>({});

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const next: Errors = {};
    const name = String(form.get("name") ?? "").trim();
    const email = String(form.get("email") ?? "").trim();
    const message = String(form.get("message") ?? "").trim();
    if (!name) next.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email address.";
    if (message.length < 20) next.message = "Give us a little detail — at least a sentence or two.";
    setErrors(next);
    if (Object.keys(next).length > 0) {
      toast.error("Please fix the highlighted fields.");
      return;
    }
    toast.success("Inquiry sent — a dispatcher will reply shortly.");
    navigate({ to: "/success", search: { from: "contact" } });
  };

  const field = (error: string | undefined, node: React.ReactNode) => (
    <div className="space-y-2">
      {node}
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}
    </div>
  );

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="border-b bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-20">
            <Eyebrow>Contact</Eyebrow>
            <h1 className="mt-3 max-w-3xl text-4xl font-extrabold tracking-tight sm:text-5xl">
              Talk to a dispatcher about your trucks
            </h1>
            <p className="mt-5 max-w-2xl text-lg leading-relaxed text-muted-foreground">
              Call the dispatch line for anything urgent — it's staffed 24/7 and a person picks up.
              For quotes, onboarding, and partnership questions, the form below is fastest.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
            {/* Info column */}
            <div className="space-y-6">
              {[
                {
                  icon: Phone,
                  title: "Dispatch line",
                  value: site.dispatchLine,
                  sub: "24/7 — always a dispatcher on duty",
                  href: `tel:${site.dispatchLine.replace(/\D/g, "")}`,
                },
                {
                  icon: Mail,
                  title: "Email",
                  value: site.email,
                  sub: "Replies within one business hour",
                  href: `mailto:${site.email}`,
                },
                {
                  icon: MapPin,
                  title: "Headquarters",
                  value: site.address,
                  sub: `Serving ${site.serviceArea}`,
                },
              ].map((c) => (
                <div key={c.title} className="flex gap-4 rounded-xl border bg-card p-5">
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-primary text-signal">
                    <c.icon className="size-5" />
                  </span>
                  <div>
                    <h3 className="font-display text-sm font-bold uppercase tracking-wider text-ink-soft">
                      {c.title}
                    </h3>
                    {c.href ? (
                      <a href={c.href} className="mt-1 block font-semibold hover:text-primary">
                        {c.value}
                      </a>
                    ) : (
                      <p className="mt-1 font-semibold">{c.value}</p>
                    )}
                    <p className="text-xs text-muted-foreground">{c.sub}</p>
                  </div>
                </div>
              ))}

              <div className="rounded-xl border bg-card p-5">
                <h3 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wider text-ink-soft">
                  <Clock className="size-4 text-primary" /> Hours
                </h3>
                <dl className="mt-3 space-y-2 text-sm">
                  {site.hours.map((h) => (
                    <div key={h.label} className="flex justify-between gap-4">
                      <dt className="text-muted-foreground">{h.label}</dt>
                      <dd className="text-right font-semibold">{h.value}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={submit} noValidate className="space-y-6 rounded-2xl border bg-card p-6 sm:p-8">
              <div className="grid gap-6 sm:grid-cols-2">
                {field(
                  errors.name,
                  <>
                    <Label htmlFor="name">Name *</Label>
                    <Input id="name" name="name" placeholder="Your name" autoComplete="name" />
                  </>,
                )}
                {field(
                  errors.email,
                  <>
                    <Label htmlFor="email">Email *</Label>
                    <Input id="email" name="email" type="email" placeholder="you@example.com" autoComplete="email" />
                  </>,
                )}
              </div>
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" name="phone" type="tel" placeholder="(214) 555-0100" autoComplete="tel" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="equipment">Equipment type</Label>
                  <Select name="equipment" defaultValue="dry-van">
                    <SelectTrigger id="equipment">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dry-van">Dry van</SelectItem>
                      <SelectItem value="reefer">Refrigerated</SelectItem>
                      <SelectItem value="flatbed">Flatbed / step deck</SelectItem>
                      <SelectItem value="power-only">Power only</SelectItem>
                      <SelectItem value="other">Other / mixed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="trucks">Trucks in operation</Label>
                <Select name="trucks" defaultValue="1">
                  <SelectTrigger id="trucks">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 (owner-operator)</SelectItem>
                    <SelectItem value="2-5">2–5</SelectItem>
                    <SelectItem value="6-15">6–15</SelectItem>
                    <SelectItem value="16-30">16–30</SelectItem>
                    <SelectItem value="30+">30+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {field(
                errors.message,
                <>
                  <Label htmlFor="message">How can we help? *</Label>
                  <Textarea
                    id="message"
                    name="message"
                    rows={5}
                    placeholder="Tell us about your equipment, lanes, and what you need from a dispatch desk…"
                  />
                </>,
              )}
              <Button type="submit" size="lg" className="rounded-full px-8 font-bold">
                <Send className="size-4" /> Send inquiry
              </Button>
            </form>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
