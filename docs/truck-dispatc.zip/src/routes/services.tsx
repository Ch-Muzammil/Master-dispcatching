import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { CtaBand, PageHero, SectionHeading } from "@/components/site/blocks";
import { Button } from "@/components/ui/button";
import { services } from "@/data/services";

export const Route = createFileRoute("/services")({
  head: () =>
    buildHead({
      title: "Dispatch Services: Dry Van, Reefer, Flatbed | Meridian Dispatch Group",
      description:
        "Specialized dispatch desks for dry van, reefer, flatbed, and power only operations — plus carrier setup, FMCSA compliance, and billing support. Month-to-month terms.",
    }),
  component: Services,
});

function Services() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <PageHero
          eyebrow="Services"
          title="Dispatching that fits how you run"
          description="Every carrier runs different freight in different lanes on different schedules. So we don't offer one dispatch service — we offer desks that specialize in yours."
          breadcrumbs={[{ label: "Home", to: "/" }, { label: "Services" }]}
        />

        {/* Service index */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <div className="space-y-5">
            {services.map((s, i) => (
              <Link
                key={s.slug}
                to="/services/$slug"
                params={{ slug: s.slug }}
                className="group grid gap-6 rounded-xl border bg-card p-6 transition-all hover:-translate-y-0.5 hover:border-signal hover:shadow-lg sm:p-8 lg:grid-cols-[auto_1fr_auto] lg:items-center"
              >
                <div className="flex items-center gap-5">
                  <span className="hidden font-display text-5xl font-extrabold leading-none text-muted-foreground/15 sm:block">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="flex size-12 items-center justify-center rounded-lg bg-primary text-signal transition-colors group-hover:bg-signal group-hover:text-accent-foreground">
                    <s.icon className="size-6" />
                  </span>
                </div>
                <div>
                  <h2 className="font-display text-xl font-bold tracking-tight group-hover:underline sm:text-2xl">
                    {s.title}
                  </h2>
                  <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-[0.95rem]">
                    {s.excerpt}
                  </p>
                  <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1">
                    {s.included.slice(0, 3).map((inc) => (
                      <li key={inc} className="inline-flex items-center gap-1.5 text-xs font-medium text-ink-soft">
                        <CheckCircle2 className="size-3.5 text-primary" /> {inc.split(",")[0]?.split(" —")[0]}
                      </li>
                    ))}
                  </ul>
                </div>
                <span className="inline-flex items-center gap-1.5 self-start text-sm font-bold text-primary lg:self-center">
                  Details
                  <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                </span>
              </Link>
            ))}
          </div>
        </section>

        {/* What's standard */}
        <section className="border-y bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
            <SectionHeading
              align="center"
              eyebrow="Every desk, every carrier"
              title="Standard on every service"
            />
            <div className="mx-auto mt-10 grid max-w-4xl gap-x-10 gap-y-4 sm:grid-cols-2">
              {[
                "Dedicated dispatcher who knows your operation",
                "Rates negotiated before you accept a load",
                "Broker credit checks before booking",
                "Detention & accessorial claims pursued",
                "Same-day invoicing from PODs",
                "Month-to-month terms, no setup fees",
              ].map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-primary" />
                  <span className="text-[0.95rem] font-medium">{item}</span>
                </div>
              ))}
            </div>
            <p className="mx-auto mt-10 max-w-xl text-center text-sm text-muted-foreground">
              Pricing is a flat percentage of gross linehaul per load, quoted
              clearly on your first call. <Link to="/faqs" className="font-semibold text-primary underline-offset-4 hover:underline">Read billing FAQs</Link>
            </p>
          </div>
        </section>

        <CtaBand
          title="Not sure which desk fits your trucks?"
          body="One call is enough. Tell us your equipment and lanes and we'll tell you honestly which service — or whether dispatching with us makes sense at all."
        />
      </main>
      <SiteFooter />
    </div>
  );
}
