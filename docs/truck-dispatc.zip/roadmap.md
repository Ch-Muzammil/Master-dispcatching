# Roadmap — Premium Truck Dispatching & Logistics Website

## Foundation
- [x] Design system (light theme, navy + freight amber, Archivo/Manrope)
- [x] Root shell: fonts, Toaster, branded 404
- [ ] Mock data layer (site, services, careers, blog, admin datasets)
- [ ] Shared components (header, footer, section headings, CTA band, admin shell)

## Public website (15 pages)
- [ ] Home
- [ ] About
- [ ] Services overview + Service details (dynamic)
- [ ] Careers + Job details + Application form
- [ ] Blog listing + Article page
- [ ] FAQs (accordion, grouped)
- [ ] Contact (form with validation)
- [ ] Privacy Policy, Terms
- [ ] Form success page (contact + application variants)
- [ ] Branded 404

## Admin dashboard (13 screens)
- [ ] Mock login gate (localStorage session)
- [ ] Dashboard overview (stats, activity, charts)
- [ ] Website settings, Page management, Services mgmt, Jobs mgmt
- [ ] Job applications (status filters, CV links), Blog mgmt, FAQs mgmt
- [ ] Media library, SEO settings, Navigation mgmt, Profile & security

## QA
- [ ] Build clean, routes verified, key flows driven in browser
