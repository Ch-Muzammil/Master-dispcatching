import type { ReactNode } from "react";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import {
  FileText,
  Globe,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Mail,
  Menu,
  Newspaper,
  Package,
  Search,
  Settings,
  ShieldCheck,
  Truck,
  UserRoundCog,
  Users,
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Logo } from "@/components/site/logo";
import { adminAuth } from "@/lib/admin-auth";
import aboutOpsSrc from "@/assets/about-ops.jpg";
import { adminProfile } from "@/data/admin";
import { cn } from "@/lib/utils";

const navGroups: { heading: string; items: { label: string; to: string; icon: typeof Globe }[] }[] = [
  {
    heading: "Overview",
    items: [{ label: "Dashboard", to: "/admin", icon: LayoutDashboard }],
  },
  {
    heading: "Website content",
    items: [
      { label: "Pages", to: "/admin/pages", icon: FileText },
      { label: "Services", to: "/admin/services", icon: Truck },
      { label: "Jobs", to: "/admin/jobs", icon: Package },
      { label: "Applications", to: "/admin/applications", icon: Users },
      { label: "Blog", to: "/admin/blog", icon: Newspaper },
      { label: "FAQs", to: "/admin/faqs", icon: LifeBuoy },
      { label: "Media library", to: "/admin/media", icon: Globe },
    ],
  },
  {
    heading: "Configuration",
    items: [
      { label: "Website settings", to: "/admin/settings", icon: Settings },
      { label: "Navigation", to: "/admin/navigation", icon: ShieldCheck },
      { label: "SEO settings", to: "/admin/seo", icon: Search },
    ],
  },
  {
    heading: "Account",
    items: [{ label: "Profile & security", to: "/admin/profile", icon: UserRoundCog }],
  },
];

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  const location = useLocation();
  return (
    <nav className="flex flex-col gap-6 px-3 py-6">
      {navGroups.map((group) => (
        <div key={group.heading}>
          <p className="px-3 pb-2 text-[0.65rem] font-bold uppercase tracking-[0.18em] text-white/40">
            {group.heading}
          </p>
          <div className="space-y-0.5">
            {group.items.map((item) => {
              const active =
                item.to === "/admin"
                  ? location.pathname === "/admin"
                  : location.pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={onNavigate}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    active
                      ? "bg-white/10 font-semibold text-white"
                      : "text-white/60 hover:bg-white/5 hover:text-white",
                  )}
                >
                  <item.icon className={cn("size-4", active && "text-signal")} />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );
}

export function AdminShell({
  title,
  description,
  actions,
  children,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  const navigate = useNavigate();
  const session = adminAuth.get();
  const initials = (session?.name ?? adminProfile.name)
    .split(" ")
    .map((p) => p[0])
    .join("");

  const signOut = () => {
    adminAuth.signOut();
    navigate({ to: "/admin/login" });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-white/5 bg-harbor-deep lg:flex">
        <div className="flex h-16 items-center border-b border-white/10 px-5">
          <Logo inverse />
        </div>
        <div className="flex-1 overflow-y-auto">
          <NavItems />
        </div>
        <div className="border-t border-white/10 p-4">
          <div className="flex items-center gap-3 rounded-md bg-white/5 p-3">
            <Avatar className="size-8">
              <AvatarFallback className="bg-signal text-xs font-bold text-accent-foreground">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-white">{session?.name ?? adminProfile.name}</p>
              <p className="truncate text-xs text-white/50">{adminProfile.role}</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main column */}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-30 border-b bg-background/95 backdrop-blur">
          <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
            {/* Mobile menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="lg:hidden" aria-label="Open admin menu">
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-72 bg-harbor-deep p-0 [&>button]:text-white">
                <SheetHeader className="border-b border-white/10 px-5 py-4">
                  <SheetTitle>
                    <Logo inverse />
                  </SheetTitle>
                </SheetHeader>
                <div className="overflow-y-auto">
                  <NavItems />
                </div>
              </SheetContent>
            </Sheet>

            <div className="relative hidden max-w-sm flex-1 sm:block">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search content, jobs, applications…" className="pl-9" />
            </div>

            <div className="ml-auto flex items-center gap-3">
              <Button asChild variant="outline" size="sm" className="hidden font-semibold sm:inline-flex">
                <Link to="/" target="_blank">
                  <Globe className="size-4" /> View website
                </Link>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button aria-label="Account menu" className="rounded-full outline-none ring-ring focus-visible:ring-2">
                    <Avatar className="size-9">
                      <AvatarFallback className="bg-primary text-xs font-bold text-primary-foreground">
                        {initials}
                      </AvatarFallback>
                    </Avatar>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <p className="text-sm font-semibold">{session?.name ?? adminProfile.name}</p>
                    <p className="text-xs font-normal text-muted-foreground">{session?.email ?? adminProfile.email}</p>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/admin/profile" className="cursor-pointer">
                      <UserRoundCog className="size-4" /> Profile & security
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={signOut}>
                    <LogOut className="size-4" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        <main className="px-4 py-8 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-6xl">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-foreground">{title}</h1>
                {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
              </div>
              {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
            </div>
            <div className="mt-8">{children}</div>
          </div>
        </main>
      </div>
    </div>
  );
}

export function AdminLoginShell({ children }: { children: ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden isolate overflow-hidden lg:block">
        <img
          src={aboutOpsSrc}
          alt="Dispatch operations floor"
          loading="lazy"
          width={1600}
          height={1104}
          className="absolute inset-0 -z-10 h-full w-full object-cover"
        />
        <div className="absolute inset-0 -z-10 bg-harbor-deep/80" />
        <div className="flex h-full flex-col justify-between p-10">
          <Logo inverse />
          <div>
            <Mail className="mb-4 size-6 text-signal" />
            <p className="max-w-md font-display text-2xl font-bold leading-snug text-white">
              "Our night desk keeps 25 trucks loaded while the day team sleeps.
              The admin portal is where that work gets published."
            </p>
            <p className="mt-4 text-sm text-white/60">
              Marcus Bell · Director of Dispatch Operations
            </p>
          </div>
          <p className="text-xs text-white/40">© {new Date().getFullYear()} Meridian Dispatch Group LLC</p>
        </div>
      </div>
      <div className="flex items-center justify-center bg-background px-4 py-12">{children}</div>
    </div>
  );
}

