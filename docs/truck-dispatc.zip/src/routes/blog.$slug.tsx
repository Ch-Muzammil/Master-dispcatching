import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Clock, Quote } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { Breadcrumbs, CtaBand, Eyebrow } from "@/components/site/blocks";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { getPost, relatedPosts } from "@/data/blog";

export const Route = createFileRoute("/blog/$slug")({
  head: ({ loaderData }) => {
    const post = loaderData?.post;
    return buildHead({
      title: post ? `${post.title} | Meridian Dispatch Group` : "Article | Meridian Dispatch Group",
      description: post?.excerpt ?? "Freight insights from the Meridian dispatch desk.",
    });
  },
  loader: ({ params }) => {
    const post = getPost(params.slug);
    if (!post) throw notFound();
    return { post };
  },
  component: Article,
});

function Article() {
  const { post } = Route.useLoaderData();
  const related = relatedPosts(post.slug);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero */}
        <section className="border-b bg-paper">
          <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:py-16">
            <Breadcrumbs
              items={[
                { label: "Home", to: "/" },
                { label: "Blog", to: "/blog" },
                { label: post.title },
              ]}
            />
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Eyebrow>{post.category}</Eyebrow>
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Clock className="size-3.5" /> {post.readTime}
              </span>
            </div>
            <h1 className="mt-3 text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
              {post.title}
            </h1>
            <div className="mt-6 flex items-center gap-3">
              <Avatar className="size-10">
                <AvatarFallback className="bg-primary text-xs font-bold text-primary-foreground">
                  {post.authorInitials}
                </AvatarFallback>
              </Avatar>
              <div className="text-sm">
                <p className="font-semibold">{post.author}</p>
                <p className="text-xs text-muted-foreground">
                  {post.authorRole} · {post.date}
                </p>
              </div>
            </div>
          </div>
          <div className="mx-auto max-w-5xl px-4 pb-14 sm:px-6">
            <img
              src={post.cover}
              alt={post.coverAlt}
              loading="lazy"
              width={1600}
              height={1008}
              className="aspect-[16/9] w-full rounded-2xl object-cover shadow-lg"
            />
          </div>
        </section>

        {/* Body */}
        <article className="mx-auto max-w-3xl px-4 py-14 sm:px-6 lg:py-20">
          <div className="space-y-7">
            {post.body.map((block, i) => {
              switch (block.kind) {
                case "p":
                  return (
                    <p key={i} className="text-[1.05rem] leading-relaxed text-foreground/90">
                      {block.text}
                    </p>
                  );
                case "h":
                  return (
                    <h2 key={i} className="pt-4 font-display text-2xl font-bold tracking-tight">
                      {block.text}
                    </h2>
                  );
                case "list":
                  return (
                    <ul key={i} className="space-y-3">
                      {block.items.map((item) => (
                        <li key={item} className="flex items-start gap-3 text-[1rem] text-foreground/90">
                          <span className="mt-2 size-1.5 shrink-0 rounded-full bg-signal" aria-hidden />
                          {item}
                        </li>
                      ))}
                    </ul>
                  );
                case "quote":
                  return (
                    <blockquote
                      key={i}
                      className="rounded-xl border-l-4 border-signal bg-signal-soft/60 p-6"
                    >
                      <Quote className="size-5 text-primary" />
                      <p className="mt-3 font-display text-lg font-semibold leading-snug text-foreground">
                        {block.text}
                      </p>
                    </blockquote>
                  );
              }
            })}
          </div>

          <div className="mt-12 border-t pt-8">
            <Button asChild variant="ghost" size="sm" className="font-semibold">
              <Link to="/blog">
                <ArrowLeft className="size-4" /> All articles
              </Link>
            </Button>
          </div>
        </article>

        {/* Related */}
        <section className="border-t bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-16">
            <h2 className="text-2xl font-bold tracking-tight">Keep reading</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {related.map((p) => (
                <Link
                  key={p.slug}
                  to="/blog/$slug"
                  params={{ slug: p.slug }}
                  className="group rounded-xl border bg-card p-6 transition-all hover:-translate-y-0.5 hover:shadow-md"
                >
                  <Badge variant="secondary">{p.category}</Badge>
                  <h3 className="mt-3 font-display text-lg font-bold leading-snug group-hover:underline">
                    {p.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{p.excerpt}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                    Read <ArrowRight className="size-3.5" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <CtaBand
          title="Reading about dispatching or running it?"
          body="If you'd rather have a desk handling this work for your trucks, one call is all it takes to get a plan and an honest rate."
        />
      </main>
      <SiteFooter />
    </div>
  );
}
