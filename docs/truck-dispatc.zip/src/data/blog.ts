import { img } from "./images";

export type PostBlock =
  | { kind: "p"; text: string }
  | { kind: "h"; text: string }
  | { kind: "list"; items: string[] }
  | { kind: "quote"; text: string };

export type Post = {
  slug: string;
  title: string;
  category: string;
  excerpt: string;
  author: string;
  authorRole: string;
  authorInitials: string;
  date: string;
  readTime: string;
  cover: string;
  coverAlt: string;
  body: PostBlock[];
};

export const postCategories = [
  "All posts",
  "Dispatch guides",
  "Market insights",
  "Compliance",
  "Company news",
];

export const posts: Post[] = [
  {
    slug: "evaluate-dispatch-service",
    title: "How to Evaluate a Truck Dispatch Service Before You Sign",
    category: "Dispatch guides",
    excerpt:
      "The dispatch market is crowded with big promises and thin follow-through. Here's the checklist we'd hand a friend before they signed with anyone — including us.",
    author: "Dana Whitfield",
    authorRole: "Head of Carrier Success",
    authorInitials: "DW",
    date: "Oct 21, 2026",
    readTime: "7 min read",
    cover: img.aboutOps,
    coverAlt: "Dispatcher reviewing load boards on multiple screens",
    body: [
      {
        kind: "p",
        text: "A dispatch service becomes a part of your business the moment you sign — they negotiate your rates, handle your brokers, and talk to your customers' customers. Choosing well is one of the highest-leverage decisions an owner-operator makes. Choosing badly costs you more than the fee.",
      },
      { kind: "h", text: "1. Ask exactly how they get paid" },
      {
        kind: "p",
        text: "The standard model is a percentage of gross linehaul — typically 4% to 10%. Anything outside that structure deserves scrutiny. Flat per-load fees can be fine for high-volume carriers but expensive for long-haul freight. Avoid anyone who earns from broker side deals you can't see.",
      },
      {
        kind: "list",
        items: [
          "Is the fee a percentage of gross, and of what exactly — linehaul only, or accessorials too?",
          "Are there setup fees, cancellation fees, or minimum commitments?",
          "Do they accept payment directly from brokers, or does the money always land in your account first?",
        ],
      },
      { kind: "h", text: "2. Meet the actual dispatcher, not the salesperson" },
      {
        kind: "p",
        text: "The person selling you the service is rarely the person working your loads. Ask for a call with your prospective dispatcher. You're listening for lane knowledge, negotiation instincts, and whether they ask about your home time before they ask about your truck.",
      },
      { kind: "h", text: "3. Check how they handle the bad days" },
      {
        kind: "p",
        text: "Any dispatch service looks good when the board is hot. Ask specific questions: Who works your truck when your dispatcher is on vacation? What happens when a broker refuses to pay a detention claim? How do they document a load that went wrong? Good answers are process-based, not personality-based.",
      },
      {
        kind: "quote",
        text: "The best dispatch question we ever got from a carrier: 'Show me a load you lost money on and what you did about it.' That's the one we answered proudest.",
      },
      { kind: "h", text: "4. Verify the compliance backbone" },
      {
        kind: "p",
        text: "Your dispatcher handles your paperwork with brokers — which means they touch your authority's reputation. Ask whether they vet broker credit before booking, how they store your documents, and whether their setup packets are complete enough to pass a shipper's review.",
      },
      { kind: "h", text: "5. Start with a trial desk, not a long contract" },
      {
        kind: "p",
        text: "We recommend month-to-month terms until trust is earned — and we practice that ourselves. If a company needs a six-month lock-in to make its economics work, ask yourself what they expect the second month to feel like.",
      },
      {
        kind: "p",
        text: "Run this checklist on us if you're considering Meridian. It holds up, and it should — we wrote it for the carriers we want to work with.",
      },
    ],
  },
  {
    slug: "spot-vs-contract-rates",
    title: "Spot Rates vs. Contract Rates: What Owner-Operators Should Know",
    category: "Market insights",
    excerpt:
      "Contract freight pays less per load but shows up every week. Spot freight pays more when it's hot and disappears when it isn't. The right answer depends on your truck, your lanes, and your risk tolerance.",
    author: "Marcus Bell",
    authorRole: "Director of Dispatch Operations",
    authorInitials: "MB",
    date: "Oct 14, 2026",
    readTime: "6 min read",
    cover: img.heroFleet,
    coverAlt: "Freight pricing charts on a dispatch office screen",
    body: [
      {
        kind: "p",
        text: "Every owner-operator eventually faces the same fork: chase the spot market's best week, or lock into contract lanes that pay steadily and never thrill. Getting this decision right matters more than most negotiation tactics combined.",
      },
      { kind: "h", text: "What the difference actually is" },
      {
        kind: "p",
        text: "Spot rates are the live market price for a one-time move — set by supply and demand at the moment of booking. Contract rates are negotiated rates for repeated freight, usually for a month or a quarter, agreed before the freight moves. Contract rates typically sit below spot in hot markets and above spot in soft ones.",
      },
      { kind: "h", text: "When spot works in your favor" },
      {
        kind: "list",
        items: [
          "You run regions with seasonal surges you can time",
          "Your fixed costs are low and your home time is flexible",
          "You have a dispatcher watching the board in real time, not after hours",
        ],
      },
      { kind: "h", text: "When contract freight wins" },
      {
        kind: "list",
        items: [
          "You have a truck payment that doesn't care what the market did this week",
          "You want home time on a schedule, not a hope",
          "You're building toward a second truck and need bankable revenue",
        ],
      },
      { kind: "h", text: "The hybrid most successful carriers run" },
      {
        kind: "p",
        text: "The pattern we see in carriers who last: cover your baseline with two or three contract lanes, then let a dispatcher fill the gaps with spot freight at negotiated rates. You get predictability where it matters and upside where it's cheap to chase.",
      },
      {
        kind: "p",
        text: "If you're an owner-operator doing this math alone, you're doing it with one truck's data. Our dispatchers do it across 140 trucks — the lane intelligence compounds, and it's part of what the dispatch fee actually buys.",
      },
    ],
  },
  {
    slug: "fmcsa-compliance-checklist",
    title: "FMCSA Compliance Checklist for Small Carriers",
    category: "Compliance",
    excerpt:
      "Audits rarely ambush carriers that keep tidy records. This is the checklist our compliance team walks through with every carrier at onboarding — condensed to one page.",
    author: "Priya Raman",
    authorRole: "Compliance Lead",
    authorInitials: "PR",
    date: "Oct 6, 2026",
    readTime: "8 min read",
    cover: img.svcReefer,
    coverAlt: "Carrier paperwork and FMCSA documentation on a desk",
    body: [
      {
        kind: "p",
        text: "FMCSA compliance is less about knowing exotic rules and more about doing boring things consistently. Most findings in small-carrier audits trace back to a handful of preventable gaps. Here's the working list our compliance desk uses.",
      },
      { kind: "h", text: "Authority & registration" },
      {
        kind: "list",
        items: [
          "MC number active and USDOT number current",
          "Biennial USDOT filing completed (every 2 years, easy to forget)",
          "UCR registration filed for the current year",
          "BOC-3 process agent designation on file",
          "Operating authority insurance meets or exceeds minimums",
        ],
      },
      { kind: "h", text: "Driver files" },
      {
        kind: "list",
        items: [
          "Valid CDL with proper endorsements on file",
          "Motor vehicle record checked annually and at hire",
          "Driver qualification file complete for every driver",
          "Drug & alcohol clearinghouse queries documented",
        ],
      },
      { kind: "h", text: "Equipment & operations" },
      {
        kind: "list",
        items: [
          "Annual vehicle inspection records current for every unit",
          "ELD functioning and registered — no unexplained gaps in logs",
          "Hours-of-service violations tracked and addressed, not ignored",
          "DVIRs completed and defects corrected before dispatch",
        ],
      },
      { kind: "h", text: "The habit that matters most" },
      {
        kind: "p",
        text: "Pick one day each month and audit yourself against this list. Carriers who do that rarely see an audit go badly — because the audit is just confirming what they already know. Carriers who 'wait until it matters' are betting their authority on their memory.",
      },
      {
        kind: "p",
        text: "Meridian's compliance desk runs this checklist for every carrier we dispatch. If you'd rather dispatch than file paperwork, that's exactly the point.",
      },
    ],
  },
  {
    slug: "authority-to-first-load",
    title: "From Authority to First Load: A 30-Day Plan for New Authorities",
    category: "Dispatch guides",
    excerpt:
      "Your MC number is active — now what? The first month sets the trajectory for your first year. Here's the sequence that gets new authorities earning without the expensive detours.",
    author: "Dana Whitfield",
    authorRole: "Head of Carrier Success",
    authorInitials: "DW",
    date: "Sep 28, 2026",
    readTime: "9 min read",
    cover: img.ctaYard,
    coverAlt: "New carrier setup documents and a truck at a depot",
    body: [
      {
        kind: "p",
        text: "The gap between an active authority and a first revenue load is where most new carriers make their costliest mistakes — paying for setups they don't need, chasing freight they can't legally haul, or signing with the first broker who calls. Thirty days of sequence beats six months of improvisation.",
      },
      { kind: "h", text: "Week 1: Build the foundation" },
      {
        kind: "list",
        items: [
          "Confirm insurance is filed and the MCS-150 reflects your actual operation",
          "Join the Drug & Alcohol Clearinghouse as an employer",
          "Set up IFTA if you'll cross state lines regularly",
          "Open a dedicated business bank account — never commingle",
        ],
      },
      { kind: "h", text: "Week 2: Get setup-ready" },
      {
        kind: "p",
        text: "Assemble your carrier packet: W-9, COI, authority letters, bank letter, and references. Every hour a broker spends chasing your missing paperwork is an hour you're not getting loads. A complete packet is the cheapest marketing a new carrier owns.",
      },
      { kind: "h", text: "Week 3: Pick your first lanes deliberately" },
      {
        kind: "p",
        text: "Don't take the first load — take the right first load. Choose freight slightly below your revenue target in lanes with strong return freight. The goal of week three is a clean, documented, on-time first delivery, not a record gross.",
      },
      { kind: "h", text: "Week 4: Build the flywheel" },
      {
        kind: "list",
        items: [
          "Request broker references from every shipper that pays clean",
          "Log your actual cost per mile — fuel, insurance, maintenance, fees",
          "Review which lanes paid best after fuel and deadhead",
          "Decide: dispatch yourself, or bring in a dispatcher before bad habits set",
        ],
      },
      {
        kind: "quote",
        text: "The carriers who thrive in year one are the ones who treat month one as an investment period, not a panic period.",
      },
      {
        kind: "p",
        text: "Meridian's carrier setup service exists precisely for this window. We've walked hundreds of new authorities through it — the checklist above is the honest, unglamorous core of how it works.",
      },
    ],
  },
];

export function getPost(slug: string) {
  return posts.find((p) => p.slug === slug);
}

export function relatedPosts(slug: string, count = 2) {
  return posts.filter((p) => p.slug !== slug).slice(0, count);
}
