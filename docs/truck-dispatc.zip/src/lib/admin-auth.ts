const ADMIN_SESSION_KEY = "mdg-admin-session";

export type AdminSession = { email: string; name: string };

export const adminAuth = {
  get(): AdminSession | null {
    if (typeof window === "undefined") return null;
    try {
      const raw = window.localStorage.getItem(ADMIN_SESSION_KEY);
      return raw ? (JSON.parse(raw) as AdminSession) : null;
    } catch {
      return null;
    }
  },
  signIn(email: string, name = "Dana Whitfield") {
    window.localStorage.setItem(
      ADMIN_SESSION_KEY,
      JSON.stringify({ email, name } satisfies AdminSession),
    );
  },
  signOut() {
    window.localStorage.removeItem(ADMIN_SESSION_KEY);
  },
};
