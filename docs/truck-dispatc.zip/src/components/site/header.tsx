import { useEffect, useState } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { ChevronDown, Clock, Menu, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Logo } from "./logo";
import { site, publicNav } from "@/data/site";
import { services } from "@/data/services";
import { cn } from "@/lib/utils";

function NavLink({ to, label }: { to: string; label: string }) {
  const location = useLocation();
  const active = to === "/" ? location.pathname === "/" : location.pathname.startsWith(to);
  return (
    <Link
      to={to}
      className={cn(
        "relative py-2 text-sm font-semibold transition-colors",
        active
          ? "text-foreground after:absolute after:inset-x-0 after:-bottom-px after:h-0.5 after:bg-signal"
          : "text-muted-foreground hover:text-foreground",
      )}
    >
      {label}
    </Link>
  );
}

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="sticky top-0 z-50">
      {/* Utility bar */}
      <div className="hidden bg-harbor-deep text-white/85 md:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-2 text-xs font-medium">
          <div className="flex items-center gap-5">
            <a href={`tel:${site.dispatchLine.replace(/\D/g, "")}`} className="inline-flex items-center gap-1.5 transition-colors hover:text-white">
              <Phone className="size-3.5 text-signal" /> 24/7 dispatch line: {site.dispatchLine}
            </a>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="size-3.5 text-signal" /> Office hours: Mon–Fri, 8 AM – 6 PM CT
            </span>
          </div>
          <div className="flex items-center gap-5">
            <span className="text-white/60">Dispatching carriers across 48 states</span>
            <Link to="/careers" className="font-semibold text-signal hover:underline">
              We're hiring
            </Link>
          </div>
        </div>
      </div>

      {/* Main bar */}
      <div
        className={cn(
          "border-b bg-background/95 backdrop-blur transition-shadow",
          scrolled ? "shadow-[0_8px_24px_-16px_rgb(0_0_0/0.25)]" : "border-border",
        )}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <Logo />
          <nav className="hidden items-center gap-7 lg:flex">
            <NavLink to="/" label="Home" />
            <NavLink to="/about" label="About" />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="inline-flex items-center gap-1 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
                  Services <ChevronDown className="size-3.5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-80 p-2">
                {services.map((s) => (
                  <DropdownMenuItem key={s.slug} asChild>
                    <Link to="/services/$slug" params={{ slug: s.slug }} className="flex cursor-pointer items-start gap-3 rounded-md p-2">
                      <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-secondary text-primary">
                        <s.icon className="size-4" />
                      </span>
                      <span>
                        <span className="block text-sm font-semibold text-foreground">{s.title}</span>
                        <span className="line-clamp-1 text-xs text-muted-foreground">{s.excerpt}</span>
                      </span>
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <NavLink to="/careers" label="Careers" />
            <NavLink to="/blog" label="Blog" />
            <NavLink to="/faqs" label="FAQs" />
            <NavLink to="/contact" label="Contact" />
          </nav>
          <div className="flex items-center gap-2">
            <Button asChild className="hidden rounded-full font-semibold sm:inline-flex">
              <Link to="/contact">Get a quote</Link>
            </Button>
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="lg:hidden" aria-label="Open menu">
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 overflow-y-auto">
                <SheetHeader>
                  <SheetTitle>
                    <Logo />
                  </SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col gap-1 px-4 pb-8">
                  {publicNav.map((item) => (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setOpen(false)}
                      className="rounded-md px-3 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
                    >
                      {item.label}
                    </Link>
                  ))}
                  <div className="mt-2 border-t pt-4">
                    <p className="px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Services</p>
                    {services.map((s) => (
                      <Link
                        key={s.slug}
                        to="/services/$slug"
                        params={{ slug: s.slug }}
                        onClick={() => setOpen(false)}
                        className="block rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                      >
                        {s.title}
                      </Link>
                    ))}
                  </div>
                  <Button asChild className="mt-4">
                    <Link to="/contact" onClick={() => setOpen(false)}>
                      Get a quote
                    </Link>
                  </Button>
                  <a
                    href={`tel:${site.dispatchLine.replace(/\D/g, "")}`}
                    className="mt-2 inline-flex items-center justify-center gap-2 rounded-md border border-input px-4 py-2.5 text-sm font-semibold"
                  >
                    <Phone className="size-4 text-signal" /> {site.dispatchLine}
                  </a>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
