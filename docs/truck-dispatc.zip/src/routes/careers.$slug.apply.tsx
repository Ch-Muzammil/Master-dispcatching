import { useState } from "react";
import { createFileRoute, notFound, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, FileUp, Send } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { Breadcrumbs, Eyebrow } from "@/components/site/blocks";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getJob } from "@/data/careers";
import { toast } from "sonner";

export const Route = createFileRoute("/careers/$slug/apply")({
  head: ({ loaderData }) =>
    buildHead({
      title: loaderData?.job
        ? `Apply: ${loaderData.job.title} | Meridian Dispatch Group`
        : "Apply | Meridian Dispatch Group",
      description: "Submit your application for a role on the Meridian dispatch team.",
    }),
  loader: ({ params }) => {
    const job = getJob(params.slug);
    if (!job) throw notFound();
    return { job };
  },
  component: ApplyPage,
});

type Errors = Partial<Record<"name" | "email" | "phone" | "experience" | "note", string>>;

function ApplyPage() {
  const { job } = Route.useLoaderData();
  const navigate = useNavigate();
  const [errors, setErrors] = useState<Errors>({});
  const [cvName, setCvName] = useState<string | null>(null);

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const next: Errors = {};
    const name = String(form.get("name") ?? "").trim();
    const email = String(form.get("email") ?? "").trim();
    const phone = String(form.get("phone") ?? "").trim();
    const note = String(form.get("note") ?? "").trim();
    const experience = String(form.get("experience") ?? "").trim();
    if (!name) next.name = "Please enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email address.";
    if (phone.replace(/\D/g, "").length < 7) next.phone = "Enter a valid phone number.";
    if (!experience) next.experience = "Select your experience level.";
    if (note.length < 30) next.note = "Tell us a bit more — at least a couple of sentences.";
    setErrors(next);
    if (Object.keys(next).length > 0) {
      toast.error("Please fix the highlighted fields.");
      return;
    }
    toast.success("Application submitted — thank you!");
    navigate({ to: "/success", search: { from: "application" } });
  };

  const field = (key: keyof Errors, error: string | undefined, node: React.ReactNode) => (
    <div className="space-y-2">
      {node}
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}
      <span className="sr-only">{key}</span>
    </div>
  );

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="border-b bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:py-16">
            <Breadcrumbs
              items={[
                { label: "Home", to: "/" },
                { label: "Careers", to: "/careers" },
                { label: job.title, to: `/careers/${job.slug}` },
                { label: "Apply" },
              ]}
            />
            <div className="mt-6 max-w-2xl">
              <Eyebrow>Application</Eyebrow>
              <h1 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">
                Apply — {job.title}
              </h1>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                Two minutes of your time and one honest paragraph beat a polished but generic cover
                letter. We read every application ourselves.
              </p>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
          <form onSubmit={submit} noValidate className="space-y-6">
            <div className="grid gap-6 sm:grid-cols-2">
              {field(
                "name",
                errors.name,
                <>
                  <Label htmlFor="name">Full name *</Label>
                  <Input id="name" name="name" placeholder="Jordan Reyes" autoComplete="name" />
                </>,
              )}
              {field(
                "email",
                errors.email,
                <>
                  <Label htmlFor="email">Email *</Label>
                  <Input id="email" name="email" type="email" placeholder="you@example.com" autoComplete="email" />
                </>,
              )}
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              {field(
                "phone",
                errors.phone,
                <>
                  <Label htmlFor="phone">Phone *</Label>
                  <Input id="phone" name="phone" type="tel" placeholder="(214) 555-0100" autoComplete="tel" />
                </>,
              )}
              {field(
                "experience",
                errors.experience,
                <>
                  <Label htmlFor="experience">Experience level *</Label>
                  <Select name="experience">
                    <SelectTrigger id="experience">
                      <SelectValue placeholder="Select experience" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="entry">Entry level</SelectItem>
                      <SelectItem value="1-3">1–3 years</SelectItem>
                      <SelectItem value="4-6">4–6 years</SelectItem>
                      <SelectItem value="7+">7+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </>,
              )}
            </div>
            {field(
              "note",
              errors.note,
              <>
                <Label htmlFor="note">Why this role? *</Label>
                <Textarea
                  id="note"
                  name="note"
                  rows={5}
                  placeholder="A couple of honest sentences about your freight background and what draws you to this desk…"
                />
              </>,
            )}
            <div className="space-y-2">
              <Label htmlFor="cv">Résumé / CV (PDF or DOC)</Label>
              <label
                htmlFor="cv"
                className="flex cursor-pointer items-center gap-3 rounded-xl border border-dashed bg-card px-5 py-6 text-sm transition-colors hover:border-signal"
              >
                <FileUp className="size-5 text-primary" />
                {cvName ? (
                  <span className="font-semibold">{cvName}</span>
                ) : (
                  <span className="text-muted-foreground">Click to upload — optional, but it helps</span>
                )}
              </label>
              <input
                id="cv"
                name="cv"
                type="file"
                accept=".pdf,.doc,.docx"
                className="sr-only"
                onChange={(e) => setCvName(e.target.files?.[0]?.name ?? null)}
              />
            </div>
            <div className="flex flex-wrap items-center gap-4">
              <Button type="submit" size="lg" className="rounded-full px-8 font-bold">
                <Send className="size-4" /> Submit application
              </Button>
              <Button asChild variant="ghost" size="sm" className="font-semibold">
                <a href={`/careers/${job.slug}`}>
                  <ArrowLeft className="size-4" /> Back to role
                </a>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              By applying you agree to our{" "}
              <a href="/privacy" className="font-semibold text-primary underline-offset-4 hover:underline">
                privacy policy
              </a>
              . Applications go only to the hiring team.
            </p>
          </form>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
