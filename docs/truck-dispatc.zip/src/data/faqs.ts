export type Faq = { q: string; a: string };
export type FaqGroup = { category: string; items: Faq[] };

export const faqGroups: FaqGroup[] = [
  {
    category: "Services & dispatching",
    items: [
      {
        q: "What exactly does a dispatch service do?",
        a: "A dispatch service runs the business side of your truck: sourcing loads, negotiating rates, handling broker setups and paperwork, tracking appointments, and managing invoicing. You stay focused on driving; we handle the freight office work that used to eat your evenings.",
      },
      {
        q: "Which equipment types do you dispatch?",
        a: "We dispatch dry van, refrigerated, flatbed, step deck, RGN, and power only operations. Each equipment type has a dedicated desk with dispatchers who specialize in its freight, permits, and rate structures.",
      },
      {
        q: "Do you force me to take loads I don't want?",
        a: "Never. Your dispatcher presents opportunities and you make the final call on every load. We learn your lanes, home-time schedule, and rate floor during onboarding so the loads we bring you are ones you'd usually say yes to anyway.",
      },
      {
        q: "What load boards and tools do you use?",
        a: "Our dispatchers work across DAT, Truckstop, and direct broker relationships built over years. Carriers get one clean dispatch sheet per load — we do the board-hunting behind the scenes.",
      },
      {
        q: "Can you dispatch a fleet, not just a single truck?",
        a: "Yes. Fleets from 2 to 30+ trucks get a dedicated dispatch team, lane planning across the whole fleet, and weekly performance reviews covering gross per truck, lane mix, and broker concentration.",
      },
    ],
  },
  {
    category: "Onboarding & setup",
    items: [
      {
        q: "How fast can I start receiving loads?",
        a: "Most carriers are dispatched within 2–3 business days of onboarding. New authorities take a little longer while insurance filings and broker setups complete — our carrier setup team usually compresses that to under two weeks.",
      },
      {
        q: "What documents do I need to onboard?",
        a: "Your MC/USDOT numbers, certificate of insurance, W-9, voided check or bank letter, and a signed dispatch agreement. Our setup team walks you through everything else, including broker packets.",
      },
      {
        q: "Is there a long-term contract?",
        a: "No. We work month-to-month with 30 days' notice in either direction. We'd rather earn your business every month than lock you into a contract you resent.",
      },
    ],
  },
  {
    category: "Rates & billing",
    items: [
      {
        q: "How much does dispatching cost?",
        a: "Our standard rate is a flat percentage of gross linehaul per load, with no setup fees or minimums. The exact percentage depends on your equipment and service level — you'll get a clear, written number on your first call, and it won't change without notice.",
      },
      {
        q: "Do you touch my money?",
        a: "No. Brokers and shippers pay you directly, into your account. We invoice and manage paperwork, but freight revenue always flows straight to you.",
      },
      {
        q: "What about detention, layover, and TONU?",
        a: "We track and pursue those claims as part of dispatching — including the documentation trail brokers need to actually pay them. Uncollected accessorials are a silent profit leak, and closing it is part of the job.",
      },
    ],
  },
  {
    category: "Careers at Meridian",
    items: [
      {
        q: "Do I need freight experience to work here?",
        a: "For dispatcher roles, yes — we want people who've lived the load boards. For load planner and coordinator roles, we hire for hunger and train hard; several of our senior dispatchers started exactly that way.",
      },
      {
        q: "Are remote positions truly remote?",
        a: "Yes. Night-shift coordinators and junior load planners work fully remote anywhere in the US, with company-provided equipment. Desk coverage rotations are planned so nobody carries the night alone.",
      },
      {
        q: "What does the interview process look like?",
        a: "A 20-minute intro call, a practical exercise built from real (anonymized) freight scenarios, then a panel with the team lead you'd actually work with. Most candidates complete the process within two weeks.",
      },
    ],
  },
];

export const faqCount = faqGroups.reduce((n, g) => n + g.items.length, 0);
