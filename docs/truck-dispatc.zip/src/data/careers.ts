export type Job = {
  slug: string;
  title: string;
  department: string;
  type: string;
  location: string;
  salary: string;
  posted: string;
  status: "Open" | "Closed" | "Draft";
  views: number;
  applicants: number;
  overview: string;
  responsibilities: string[];
  qualifications: string[];
  benefits: string[];
};

export const jobs: Job[] = [
  {
    slug: "dispatch-manager",
    title: "Dispatch Manager",
    department: "Dispatch Operations",
    type: "Full-time",
    location: "Dallas, TX · Hybrid",
    salary: "$68,000 – $85,000 / year",
    posted: "Oct 12, 2026",
    status: "Open",
    views: 486,
    applicants: 17,
    overview:
      "Own a desk of 15–20 trucks and the dispatchers supporting them. You'll set lane strategy, mentor junior coordinators, and be the escalation point when a load goes sideways at 2 AM. This is a hands-on leadership role for someone who has lived the freight and can coach others to run it clean.",
    responsibilities: [
      "Manage a book of 15–20 active trucks across dry van, reefer, and flatbed",
      "Build weekly lane plans that balance rate, deadhead, and home time",
      "Coach 2–4 dispatch coordinators on negotiation and load planning",
      "Own broker escalations, detention claims, and service failures",
      "Review rate confirmations before dispatch and enforce company standards",
      "Report weekly on gross per truck, lane mix, and broker concentration",
    ],
    qualifications: [
      "3+ years of freight dispatch or brokerage experience",
      "Working knowledge of load boards, TMS platforms, and ELD systems",
      "Track record of negotiating rates on behalf of carriers",
      "Clear, calm phone presence with drivers and brokers alike",
      "FMCSA hours-of-service and ELD compliance fluency",
    ],
    benefits: [
      "Medical, dental, and vision coverage",
      "401(k) with 4% company match",
      "Hybrid schedule — 3 days in office",
      "Paid time off plus paid freight-industry training",
    ],
  },
  {
    slug: "night-shift-freight-coordinator",
    title: "Freight Coordinator — Night Shift",
    department: "Dispatch Operations",
    type: "Full-time",
    location: "Remote (US)",
    salary: "$20 – $25 / hour + shift differential",
    posted: "Oct 8, 2026",
    status: "Open",
    views: 612,
    applicants: 24,
    overview:
      "Run the overnight desk from 6 PM to 2 AM CT. Night freight doesn't negotiate itself: you'll source loads, confirm appointments, and keep trucks rolling while the day desk sleeps. Strong candidates treat the quiet hours as an advantage, not a shift.",
    responsibilities: [
      "Source and book overnight freight for 25+ trucks across time zones",
      "Confirm next-day pickup appointments and update delivery schedules",
      "Handle check calls, breakdowns, and broker issues after hours",
      "Prepare dispatch packets so morning drivers start loaded, not lost",
      "Hand off cleanly to the day desk with written shift summaries",
    ],
    qualifications: [
      "1+ year in dispatch, brokerage, or carrier operations",
      "Comfortable working independently through the night",
      "Sharp written communication — the handoff notes matter",
      "Familiarity with DAT, Truckstop, or similar load boards",
    ],
    benefits: [
      "Night shift differential on top of base rate",
      "Fully remote with company-provided equipment",
      "Medical, dental, and vision coverage",
      "Four-day work week rotation",
    ],
  },
  {
    slug: "carrier-relations-liaison",
    title: "Carrier Relations Liaison",
    department: "Carrier Success",
    type: "Full-time",
    location: "Dallas, TX · On-site",
    salary: "$55,000 – $70,000 / year",
    posted: "Sep 30, 2026",
    status: "Open",
    views: 341,
    applicants: 11,
    overview:
      "Be the face of Meridian to our carriers. You'll onboard new authorities, run quarterly business reviews with fleet owners, and turn churn risk into renewals. The role sits between sales and operations — part teacher, part advocate, part troubleshooter.",
    responsibilities: [
      "Onboard new carriers: packets, compliance checks, and dispatcher matching",
      "Run quarterly reviews covering gross, lane mix, and growth plans",
      "Resolve satisfaction issues before they become cancellations",
      "Maintain the carrier playbook and onboarding materials",
      "Feed carrier feedback into service and pricing decisions",
    ],
    qualifications: [
      "2+ years in carrier sales, account management, or dispatch",
      "Genuine respect for owner-operators and small fleets",
      "Organized enough to run 40+ relationships without dropping any",
      "Bilingual English/Spanish strongly preferred",
    ],
    benefits: [
      "Medical, dental, and vision coverage",
      "401(k) with 4% company match",
      "Annual performance bonus tied to carrier retention",
      "Paid industry conferences and certifications",
    ],
  },
  {
    slug: "junior-load-planner",
    title: "Junior Load Planner",
    department: "Dispatch Operations",
    type: "Full-time",
    location: "Remote (US)",
    salary: "$42,000 – $52,000 / year",
    posted: "Oct 18, 2026",
    status: "Open",
    views: 209,
    applicants: 31,
    overview:
      "Start your freight career on a real desk. You'll support senior dispatchers with load research, appointment scheduling, and paperwork — and learn the negotiation craft from people who do it daily. We promote from this seat first.",
    responsibilities: [
      "Research loads across DAT, Truckstop, and direct boards",
      "Prepare rate comparison sheets for senior dispatchers",
      "Schedule appointments and maintain delivery calendars",
      "Assemble broker packets and rate confirmation records",
      "Log check calls and update the TMS in real time",
    ],
    qualifications: [
      "Freight curiosity — experience welcome, hunger required",
      "Solid spreadsheet skills and attention to detail",
      "Professional phone and chat communication",
      "Available for a 2 PM – 10 PM CT training rotation for the first 90 days",
    ],
    benefits: [
      "Structured mentorship with a senior dispatcher",
      "Fully remote with company-provided equipment",
      "Medical, dental, and vision coverage",
      "Defined promotion path to coordinator in 12–18 months",
    ],
  },
  {
    slug: "safety-compliance-specialist",
    title: "Safety & Compliance Specialist",
    department: "Compliance",
    type: "Full-time",
    location: "Dallas, TX · Hybrid",
    salary: "$60,000 – $78,000 / year",
    posted: "Sep 22, 2026",
    status: "Closed",
    views: 554,
    applicants: 26,
    overview:
      "Keep 140 carriers audit-ready. You'll monitor safety scores, manage corrective action plans, and guide carriers through FMCSA reviews. This role closed on Oct 20, 2026 — we keep it posted for reference while the new hire ramps up.",
    responsibilities: [
      "Monitor SMS scores and BASIC categories across the carrier base",
      "Prepare and manage DataQ challenges and corrections",
      "Guide carriers through FMCSA safety audits",
      "Maintain insurance, UCR, and IFTA filing calendars",
      "Deliver quarterly compliance training to dispatchers",
    ],
    qualifications: [
      "3+ years in carrier safety or compliance roles",
      "Deep FMCSA regulations knowledge, including CSA methodology",
      "Experience preparing for and surviving audits",
      "Comfortable presenting to drivers and fleet owners",
    ],
    benefits: [
      "Medical, dental, and vision coverage",
      "401(k) with 4% company match",
      "Hybrid schedule — 3 days in office",
      "Annual compliance certification budget",
    ],
  },
];

export function getJob(slug: string) {
  return jobs.find((j) => j.slug === slug);
}

export const jobDepartments = [
  "All departments",
  "Dispatch Operations",
  "Carrier Success",
  "Compliance",
];
