import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Clock } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { CtaBand, PageHero, SectionHeading } from "@/components/site/blocks";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { postCategories, posts } from "@/data/blog";

export const Route = createFileRoute("/blog")({
  head: () =>
    buildHead({
      title: "Freight Insights & Dispatch Guides | Meridian Dispatch Group",
      description:
        "Practical articles on rates, compliance, and growing a trucking business — written by working dispatchers, not content marketers.",
    }),
  component: Blog,
});

function Blog() {
  const [cat, setCat] = useState(postCategories[0]);
  const filtered = cat === postCategories[0] ? posts : posts.filter((p) => p.category === cat);
  const [featured, ...rest] = filtered;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <PageHero
          eyebrow="Freight insights"
          title="Dispatch guides, written at the desk"
          description="Rate strategy, compliance checklists, and growth advice from dispatchers who negotiate freight every day. No fluff, no recycled listicles."
          breadcrumbs={[{ label: "Home", to: "/" }, { label: "Blog" }]}
        />

        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <div className="flex flex-wrap gap-2">
            {postCategories.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={
                  c === cat
                    ? "rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground"
                    : "rounded-full border border-input bg-background px-4 py-1.5 text-sm font-semibold text-muted-foreground transition-colors hover:bg-secondary"
                }
              >
                {c}
              </button>
            ))}
          </div>

          {featured && (
            <Link
              to="/blog/$slug"
              params={{ slug: featured.slug }}
              className="group mt-10 grid gap-8 overflow-hidden rounded-2xl border bg-card transition-all hover:-translate-y-0.5 hover:shadow-lg lg:grid-cols-2"
            >
              <img
                src={featured.cover}
                alt={featured.coverAlt}
                loading="lazy"
                width={1600}
                height={1008}
                className="aspect-[16/10] h-full w-full object-cover lg:rounded-l-2xl"
              />
              <div className="flex flex-col justify-center p-8 sm:p-10">
                <div className="flex flex-wrap items-center gap-3">
                  <Badge className="bg-signal font-semibold text-accent-foreground">{featured.category}</Badge>
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Clock className="size-3.5" /> {featured.readTime}
                  </span>
                </div>
                <h2 className="mt-4 font-display text-2xl font-bold tracking-tight group-hover:underline sm:text-3xl">
                  {featured.title}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">
                  {featured.excerpt}
                </p>
                <div className="mt-6 flex items-center gap-3">
                  <Avatar className="size-9">
                    <AvatarFallback className="bg-primary text-xs font-bold text-primary-foreground">
                      {featured.authorInitials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-sm">
                    <p className="font-semibold">{featured.author}</p>
                    <p className="text-xs text-muted-foreground">
                      {featured.authorRole} · {featured.date}
                    </p>
                  </div>
                </div>
                <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-bold text-primary">
                  Read article <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          )}

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {rest.map((post) => (
              <Link
                key={post.slug}
                to="/blog/$slug"
                params={{ slug: post.slug }}
                className="group flex flex-col overflow-hidden rounded-xl border bg-card transition-all hover:-translate-y-0.5 hover:shadow-lg"
              >
                <img
                  src={post.cover}
                  alt={post.coverAlt}
                  loading="lazy"
                  width={1600}
                  height={1008}
                  className="aspect-[16/9] w-full object-cover"
                />
                <div className="flex flex-1 flex-col p-6">
                  <div className="flex items-center gap-3 text-xs">
                    <Badge variant="secondary">{post.category}</Badge>
                    <span className="text-muted-foreground">{post.readTime}</span>
                  </div>
                  <h3 className="mt-3 font-display text-lg font-bold leading-snug group-hover:underline">
                    {post.title}
                  </h3>
                  <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{post.excerpt}</p>
                  <p className="mt-auto pt-4 text-xs font-medium text-muted-foreground">
                    {post.author} · {post.date}
                  </p>
                </div>
              </Link>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="mt-10 rounded-xl border bg-card p-8 text-center text-sm text-muted-foreground">
              No articles in this category yet — new guides go up twice a month.
            </p>
          )}
        </section>

        <section className="border-t bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-16">
            <SectionHeading
              align="center"
              eyebrow="Stay sharp"
              title="One practical freight email, twice a month"
              description="New guides, rate notes, and compliance reminders. Unsubscribe whenever — we'd rather be useful than frequent."
            />
          </div>
        </section>

        <CtaBand />
      </main>
      <SiteFooter />
    </div>
  );
}
