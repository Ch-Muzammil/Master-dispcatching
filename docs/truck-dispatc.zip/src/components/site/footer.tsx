import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone, Twitter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Logo } from "./logo";
import { site, footerNav } from "@/data/site";
import { toast } from "sonner";

const socialIcons: Record<string, typeof Linkedin> = {
  linkedin: Linkedin,
  facebook: Facebook,
  instagram: Instagram,
  x: Twitter,
};

export function SiteFooter() {
  return (
    <footer className="bg-harbor-deep text-white">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-16">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Logo inverse />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-white/60">
              Professional truck dispatching for US owner-operators and fleets.
              We run the freight office so you can run the road.
            </p>
            <div className="mt-6 flex gap-2">
              {site.socials.map((s) => {
                const Icon = socialIcons[s.icon] ?? Linkedin;
                return (
                  <a
                    key={s.label}
                    href={s.href}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={s.label}
                    className="flex size-9 items-center justify-center rounded-md bg-white/10 text-white/80 transition-colors hover:bg-signal hover:text-accent-foreground"
                  >
                    <Icon className="size-4" />
                  </a>
                );
              })}
            </div>
          </div>

          {footerNav.slice(0, 2).map((col) => (
            <nav key={col.heading} aria-label={col.heading}>
              <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-signal">
                {col.heading}
              </h3>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label + l.to}>
                    <Link
                      to={l.to}
                      className="text-sm text-white/70 transition-colors hover:text-white"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}

          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-signal">
              Head office
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-white/70">
              <li className="flex gap-2.5">
                <MapPin className="mt-0.5 size-4 shrink-0 text-signal" />
                {site.address}
              </li>
              <li className="flex gap-2.5">
                <Phone className="mt-0.5 size-4 shrink-0 text-signal" />
                <span>
                  <a href={`tel:${site.dispatchLine.replace(/\D/g, "")}`} className="font-semibold text-white hover:underline">
                    {site.dispatchLine}
                  </a>
                  <span className="block text-xs text-white/50">24/7 dispatch desk</span>
                </span>
              </li>
              <li className="flex gap-2.5">
                <Mail className="mt-0.5 size-4 shrink-0 text-signal" />
                <a href={`mailto:${site.email}`} className="hover:text-white">
                  {site.email}
                </a>
              </li>
            </ul>
            <form
              className="mt-6"
              onSubmit={(e) => {
                e.preventDefault();
                (e.target as HTMLFormElement).reset();
                toast.success("You're on the list", {
                  description: "Monthly freight insights, no spam.",
                });
              }}
            >
              <label htmlFor="footer-newsletter" className="text-xs font-semibold text-white/60">
                Monthly freight insights
              </label>
              <div className="mt-2 flex gap-2">
                <Input
                  id="footer-newsletter"
                  type="email"
                  required
                  placeholder="you@carrierc.com"
                  className="border-white/15 bg-white/10 text-white placeholder:text-white/40 focus-visible:ring-signal"
                />
                <Button type="submit" className="shrink-0 bg-signal font-semibold text-accent-foreground hover:bg-signal/90">
                  Join
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-white/50 sm:flex-row sm:px-6">
          <p>© {new Date().getFullYear()} {site.legalName}. All rights reserved.</p>
          <nav className="flex gap-5">
            {(footerNav[2]?.links ?? []).map((l) => (
              <Link key={l.label} to={l.to} className="transition-colors hover:text-white">
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </footer>
  );
}
