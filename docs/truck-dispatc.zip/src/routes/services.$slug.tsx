import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, CheckCircle2, CircleDollarSign, Phone } from "lucide-react";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { Breadcrumbs, CtaBand, Eyebrow, SectionHeading } from "@/components/site/blocks";
import { Button } from "@/components/ui/button";
import { getService, services } from "@/data/services";
import { site } from "@/data/site";

export const Route = createFileRoute("/services/$slug")({
  head: ({ loaderData }) => {
    const service = loaderData?.service;
    return buildHead({
      title: service
        ? `${service.title} | Meridian Dispatch Group`
        : "Service | Meridian Dispatch Group",
      description: service?.excerpt ?? "Truck dispatch services by Meridian Dispatch Group.",
    });
  },
  loader: ({ params }) => {
    const service = getService(params.slug);
    if (!service) throw notFound();
    return { service };
  },
  component: ServiceDetail,
});

function ServiceDetail() {
  const { service } = Route.useLoaderData();
  const Icon = service.icon;
  const others = services.filter((s) => s.slug !== service.slug).slice(0, 3);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero */}
        <section className="border-b bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:py-16">
            <Breadcrumbs
              items={[
                { label: "Home", to: "/" },
                { label: "Services", to: "/services" },
                { label: service.title },
              ]}
            />
            <div className="mt-8 grid items-center gap-10 lg:grid-cols-2">
              <div>
                <Eyebrow>Dispatch service</Eyebrow>
                <h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">{service.title}</h1>
                <p className="mt-5 text-lg leading-relaxed text-muted-foreground">{service.excerpt}</p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Button asChild size="lg" className="rounded-full px-7 font-bold">
                    <Link to="/contact">Talk to a dispatcher</Link>
                  </Button>
                  <Button asChild size="lg" variant="outline" className="rounded-full px-7 font-bold">
                    <a href={`tel:${site.dispatchLine.replace(/\D/g, "")}`}>
                      <Phone className="size-4" /> {site.dispatchLine}
                    </a>
                  </Button>
                </div>
              </div>
              {service.image ? (
                <img
                  src={service.image}
                  alt={service.imageAlt}
                  loading="lazy"
                  width={1600}
                  height={1008}
                  className="aspect-[16/10] w-full rounded-2xl object-cover shadow-lg"
                />
              ) : (
                <div className="relative flex aspect-[16/10] w-full items-center justify-center overflow-hidden rounded-2xl bg-harbor-deep shadow-lg">
                  <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "repeating-linear-gradient(45deg, #fff 0 2px, transparent 2px 18px)" }} aria-hidden />
                  <div className="flex flex-col items-center gap-4 text-center">
                    <span className="flex size-20 items-center justify-center rounded-2xl bg-signal">
                      <Icon className="size-10 text-accent-foreground" />
                    </span>
                    <p className="max-w-xs px-6 text-sm font-medium text-white/70">
                      A dedicated desk for {service.shortTitle.toLowerCase()} operations, staffed in shifts around the clock.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Overview + included */}
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <div className="grid gap-12 lg:grid-cols-[1.15fr_1fr]">
            <div>
              <SectionHeading eyebrow="Overview" title="What this desk does for you" />
              <p className="mt-6 text-base leading-relaxed text-muted-foreground">{service.intro}</p>
              <div className="mt-10">
                <SectionHeading eyebrow="How it works" title="Four steps, start to settlement" />
                <ol className="mt-8 space-y-6">
                  {service.process.map((step, i) => (
                    <li key={step.title} className="flex gap-5">
                      <span className="flex size-10 shrink-0 items-center justify-center rounded-full border-2 border-signal bg-background font-display text-sm font-extrabold">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <div>
                        <h3 className="font-display text-base font-bold">{step.title}</h3>
                        <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                      </div>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
            <div className="space-y-6">
              <div className="rounded-xl border bg-card p-6">
                <h3 className="flex items-center gap-2 font-display text-lg font-bold">
                  <CheckCircle2 className="size-5 text-primary" /> What's included
                </h3>
                <ul className="mt-4 space-y-3">
                  {service.included.map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm text-foreground/90">
                      <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-signal" aria-hidden />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border bg-card p-6">
                <h3 className="flex items-center gap-2 font-display text-lg font-bold">
                  <CircleDollarSign className="size-5 text-primary" /> Built for
                </h3>
                <ul className="mt-4 space-y-3">
                  {service.idealFor.map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm text-foreground/90">
                      <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" aria-hidden />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl bg-signal p-6">
                <p className="font-display text-lg font-bold leading-snug text-accent-foreground">
                  Flat percentage of gross linehaul. No setup fees. Month-to-month.
                </p>
                <p className="mt-2 text-sm text-accent-foreground/75">
                  You'll get the exact number on your first call — in writing, before you commit to anything.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Other services */}
        <section className="border-t bg-paper">
          <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-16">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-2xl font-bold tracking-tight">Other dispatch desks</h2>
              <Button asChild variant="ghost" size="sm" className="font-semibold">
                <Link to="/services">
                  <ArrowLeft className="size-4" /> All services
                </Link>
              </Button>
            </div>
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              {others.map((s) => (
                <Link
                  key={s.slug}
                  to="/services/$slug"
                  params={{ slug: s.slug }}
                  className="group rounded-xl border bg-card p-5 transition-all hover:-translate-y-0.5 hover:shadow-md"
                >
                  <span className="flex size-10 items-center justify-center rounded-lg bg-secondary text-primary transition-colors group-hover:bg-signal group-hover:text-accent-foreground">
                    <s.icon className="size-5" />
                  </span>
                  <h3 className="mt-3 font-display text-base font-bold group-hover:underline">{s.title}</h3>
                  <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{s.excerpt}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                    View <ArrowRight className="size-3.5" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <CtaBand />
      </main>
      <SiteFooter />
    </div>
  );
}
