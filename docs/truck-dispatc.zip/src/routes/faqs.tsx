import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { CtaBand, PageHero } from "@/components/site/blocks";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { faqCount, faqGroups } from "@/data/faqs";

export const Route = createFileRoute("/faqs")({
  head: () =>
    buildHead({
      title: "FAQs | Meridian Dispatch Group",
      description:
        "Straight answers about dispatch fees, equipment types, onboarding timelines, contracts, and working at Meridian Dispatch Group.",
    }),
  component: Faqs,
});

function Faqs() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <PageHero
          eyebrow="FAQs"
          title="Answers, without the sales pitch"
          description={`${faqCount} of the questions carriers and candidates ask us most — answered the way we'd answer them on the phone.`}
          breadcrumbs={[{ label: "Home", to: "/" }, { label: "FAQs" }]}
        />

        <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:py-20">
          {faqGroups.map((group, gi) => (
            <div key={group.category} className={gi > 0 ? "mt-14" : ""}>
              <h2 className="font-display text-xl font-bold tracking-tight sm:text-2xl">
                {group.category}
              </h2>
              <Accordion type="single" collapsible className="mt-6">
                {group.items.map((item, i) => (
                  <AccordionItem key={item.q} value={`${gi}-${i}`}>
                    <AccordionTrigger className="text-left text-base font-semibold hover:text-foreground hover:no-underline">
                      {item.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-[0.95rem] leading-relaxed text-muted-foreground">
                      {item.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}

          <p className="mt-14 rounded-xl border bg-card p-6 text-center text-sm text-muted-foreground">
            Something we didn't cover? Call the dispatch line anytime, or{" "}
            <Link to="/contact" className="font-semibold text-primary underline-offset-4 hover:underline">
              send us a message
            </Link>
            .
          </p>
        </section>

        <CtaBand
          title="Rather just ask a dispatcher?"
          body="Our dispatch line is staffed 24/7 — a real person picks up, every time."
        />
      </main>
      <SiteFooter />
    </div>
  );
}
