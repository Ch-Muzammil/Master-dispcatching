import { img } from "./images";

export type ApplicationStatus =
  | "New"
  | "In review"
  | "Shortlisted"
  | "Interview"
  | "Rejected"
  | "Hired";

export type JobApplication = {
  id: string;
  candidate: string;
  email: string;
  phone: string;
  position: string;
  jobSlug: string;
  experience: string;
  location: string;
  applied: string;
  status: ApplicationStatus;
  cvFile: string;
  note?: string;
};

export const applications: JobApplication[] = [
  {
    id: "APP-1042",
    candidate: "Jordan Reyes",
    email: "jordan.reyes@example.com",
    phone: "(214) 555-0177",
    position: "Dispatch Manager",
    jobSlug: "dispatch-manager",
    experience: "6 years",
    location: "Garland, TX",
    applied: "Oct 22, 2026",
    status: "New",
    cvFile: "jordan-reyes-cv.pdf",
    note: "Referred by current carrier partner.",
  },
  {
    id: "APP-1041",
    candidate: "Sofia Marsh",
    email: "s.marsh@example.com",
    phone: "(469) 555-0113",
    position: "Junior Load Planner",
    jobSlug: "junior-load-planner",
    experience: "1 year",
    location: "Remote · Austin, TX",
    applied: "Oct 21, 2026",
    status: "In review",
    cvFile: "sofia-marsh-cv.pdf",
  },
  {
    id: "APP-1040",
    candidate: "Ethan Cole",
    email: "ethan.cole@example.com",
    phone: "(312) 555-0148",
    position: "Freight Coordinator — Night Shift",
    jobSlug: "night-shift-freight-coordinator",
    experience: "3 years",
    location: "Remote · Chicago, IL",
    applied: "Oct 20, 2026",
    status: "Shortlisted",
    cvFile: "ethan-cole-cv.pdf",
    note: "Strong DAT knowledge; asked about growth path.",
  },
  {
    id: "APP-1039",
    candidate: "Mariah Dunn",
    email: "mariah.dunn@example.com",
    phone: "(601) 555-0192",
    position: "Carrier Relations Liaison",
    jobSlug: "carrier-relations-liaison",
    experience: "4 years",
    location: "Dallas, TX",
    applied: "Oct 18, 2026",
    status: "Interview",
    cvFile: "mariah-dunn-cv.pdf",
    note: "Panel interview scheduled Oct 29, 10:00 AM CT.",
  },
  {
    id: "APP-1038",
    candidate: "Luis Herrera",
    email: "l.herrera@example.com",
    phone: "(210) 555-0166",
    position: "Dispatch Manager",
    jobSlug: "dispatch-manager",
    experience: "9 years",
    location: "San Antonio, TX",
    applied: "Oct 16, 2026",
    status: "In review",
    cvFile: "luis-herrera-cv.pdf",
  },
  {
    id: "APP-1037",
    candidate: "Amber Liu",
    email: "amber.liu@example.com",
    phone: "(206) 555-0129",
    position: "Junior Load Planner",
    jobSlug: "junior-load-planner",
    experience: "Entry level",
    location: "Remote · Tacoma, WA",
    applied: "Oct 14, 2026",
    status: "New",
    cvFile: "amber-liu-cv.pdf",
  },
  {
    id: "APP-1036",
    candidate: "Derek Boone",
    email: "d.boone@example.com",
    phone: "(901) 555-0135",
    position: "Freight Coordinator — Night Shift",
    jobSlug: "night-shift-freight-coordinator",
    experience: "2 years",
    location: "Remote · Memphis, TN",
    applied: "Oct 11, 2026",
    status: "Rejected",
    cvFile: "derek-boone-cv.pdf",
    note: "Not available for night rotation.",
  },
  {
    id: "APP-1035",
    candidate: "Renee Fontaine",
    email: "renee.f@example.com",
    phone: "(504) 555-0184",
    position: "Carrier Relations Liaison",
    jobSlug: "carrier-relations-liaison",
    experience: "5 years",
    location: "New Orleans, LA",
    applied: "Oct 9, 2026",
    status: "Hired",
    cvFile: "renee-fontaine-cv.pdf",
    note: "Starts Nov 9, 2026.",
  },
];

export const applicationStatuses: ApplicationStatus[] = [
  "New",
  "In review",
  "Shortlisted",
  "Interview",
  "Rejected",
  "Hired",
];

/* ---------------------------------- Media --------------------------------- */

export type MediaItem = {
  id: string;
  name: string;
  url: string;
  tags: string[];
  uploaded: string;
  size: string;
  dimensions: string;
};

const mediaSeed: Omit<MediaItem, "id">[] = [
  { name: "hero-fleet.jpg", url: img.heroFleet, tags: ["Homepage", "Hero", "Blog"], uploaded: "Oct 12, 2026", size: "412 KB", dimensions: "1920 × 1080" },
  { name: "about-ops.jpg", url: img.aboutOps, tags: ["About", "Admin login", "Blog"], uploaded: "Oct 12, 2026", size: "388 KB", dimensions: "1600 × 1100" },
  { name: "careers-driver.jpg", url: img.careersDriver, tags: ["Careers"], uploaded: "Oct 12, 2026", size: "371 KB", dimensions: "1600 × 1100" },
  { name: "cta-yard.jpg", url: img.ctaYard, tags: ["CTA band", "Blog"], uploaded: "Oct 12, 2026", size: "436 KB", dimensions: "1920 × 900" },
  { name: "svc-dryvan.jpg", url: img.svcDryVan, tags: ["Services"], uploaded: "Oct 13, 2026", size: "356 KB", dimensions: "1600 × 1000" },
  { name: "svc-reefer.jpg", url: img.svcReefer, tags: ["Services", "Blog"], uploaded: "Oct 13, 2026", size: "362 KB", dimensions: "1600 × 1000" },
];

export const mediaItems: MediaItem[] = mediaSeed.map((m, i) => ({
  ...m,
  id: `media-${String(i + 1).padStart(3, "0")}`,
}));

/* -------------------------------- Dashboard ------------------------------- */

export const dashboardStats = [
  { label: "Open job listings", value: 4, hint: "+1 this month", tone: "primary" as const },
  { label: "New applications", value: 3, hint: "Last 7 days", tone: "signal" as const },
  { label: "Published articles", value: 4, hint: "1 draft pending", tone: "primary" as const },
  { label: "Open inquiries", value: 12, hint: "2 unanswered > 24h", tone: "signal" as const },
];

export const weeklyVisitors = [
  { day: "Mon", visitors: 412, inquiries: 3 },
  { day: "Tue", visitors: 468, inquiries: 5 },
  { day: "Wed", visitors: 531, inquiries: 4 },
  { day: "Thu", visitors: 505, inquiries: 2 },
  { day: "Fri", visitors: 613, inquiries: 6 },
  { day: "Sat", visitors: 348, inquiries: 1 },
  { day: "Sun", visitors: 297, inquiries: 2 },
];

export const trafficSources = [
  { name: "Organic search", value: 46 },
  { name: "Direct", value: 24 },
  { name: "Referral", value: 17 },
  { name: "Social", value: 13 },
];

export const activityFeed = [
  { time: "2h ago", text: "Jordan Reyes applied for Dispatch Manager", tag: "Application" },
  { time: "5h ago", text: "Blog post “Spot Rates vs. Contract Rates” reached 1,000 views", tag: "Blog" },
  { time: "Yesterday", text: "Safety & Compliance Specialist listing closed", tag: "Careers" },
  { time: "Yesterday", text: "Contact inquiry from C. Boone (2 trucks, reefer)", tag: "Inquiry" },
  { time: "Oct 22", text: "New hero image uploaded to media library", tag: "Media" },
  { time: "Oct 21", text: "SEO description updated for Services page", tag: "SEO" },
];

/* --------------------------- Pages & site settings ------------------------ */

export const sitePages = [
  { id: "home", title: "Home", path: "/", status: "Published", updated: "Oct 22, 2026", blocks: 7 },
  { id: "about", title: "About us", path: "/about", status: "Published", updated: "Oct 18, 2026", blocks: 6 },
  { id: "services", title: "Services overview", path: "/services", status: "Published", updated: "Oct 15, 2026", blocks: 5 },
  { id: "careers", title: "Careers", path: "/careers", status: "Published", updated: "Oct 12, 2026", blocks: 6 },
  { id: "contact", title: "Contact", path: "/contact", status: "Published", updated: "Oct 9, 2026", blocks: 4 },
  { id: "faqs", title: "FAQs", path: "/faqs", status: "Published", updated: "Oct 5, 2026", blocks: 3 },
];

export const seoEntries = [
  { page: "Home", title: "Truck Dispatch Services for US Carriers | Meridian Dispatch Group", description: "Professional 24/7 truck dispatching for owner-operators and fleets. Load sourcing, rate negotiation, and paperwork handled.", updated: "Oct 20, 2026" },
  { page: "Services", title: "Dispatch Services: Dry Van, Reefer, Flatbed | Meridian Dispatch Group", description: "Specialized dispatch desks for every equipment type, plus carrier setup, compliance, and billing support.", updated: "Oct 15, 2026" },
  { page: "Careers", title: "Careers | Meridian Dispatch Group", description: "Join a dispatch team that treats freight like a craft. Open roles in operations, carrier success, and compliance.", updated: "Oct 12, 2026" },
  { page: "Blog", title: "Freight Insights & Dispatch Guides | Meridian Dispatch Group", description: "Practical articles on rates, compliance, and growing a trucking business — written by working dispatchers.", updated: "Oct 8, 2026" },
  { page: "Contact", title: "Contact | Meridian Dispatch Group", description: "Talk to a dispatcher about your trucks. 24/7 dispatch line, Dallas HQ, and quick inquiry form.", updated: "Oct 5, 2026" },
];

export const navigationSettings = {
  header: [
    { label: "Home", to: "/", visible: true },
    { label: "About", to: "/about", visible: true },
    { label: "Services", to: "/services", visible: true },
    { label: "Careers", to: "/careers", visible: true },
    { label: "Blog", to: "/blog", visible: true },
    { label: "FAQs", to: "/faqs", visible: true },
    { label: "Contact", to: "/contact", visible: true },
  ],
  footer: [
    { label: "Privacy policy", to: "/privacy", visible: true },
    { label: "Terms & conditions", to: "/terms", visible: true },
    { label: "Admin portal", to: "/admin", visible: true },
    { label: "Careers", to: "/careers", visible: false },
  ],
};

export const adminProfile = {
  name: "Dana Whitfield",
  email: "dana@meridiandispatch.com",
  role: "Administrator",
  initials: "DW",
  lastLogin: "Today, 8:42 AM CT",
  twoFactor: true,
};

export const adminSessions = [
  { device: "MacBook Pro · Chrome", location: "Dallas, TX", time: "Active now", current: true },
  { device: "iPhone 16 · Safari", location: "Dallas, TX", time: "2 hours ago", current: false },
  { device: "Windows PC · Edge", location: "Frisco, TX", time: "Oct 19, 2026", current: false },
];
